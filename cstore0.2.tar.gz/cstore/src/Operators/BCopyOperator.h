/* Copyright (c) 2005, Regents of Massachusetts Institute of Technology, 
 * Brandeis University, Brown University, and University of Massachusetts 
 * Boston. All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without 
 * modification, are permitted provided that the following conditions are met:
 *
 *   - Redistributions of source code must retain the above copyright notice, 
 *     this list of conditions and the following disclaimer.
 *   - Redistributions in binary form must reproduce the above copyright 
 *     notice, this list of conditions and the following disclaimer in the 
 *     documentation and/or other materials provided with the distribution.
 *   - Neither the name of Massachusetts Institute of Technology, 
 *     Brandeis University, Brown University, or University of 
 *     Massachusetts Boston nor the names of its contributors may be used 
 *     to endorse or promote products derived from this software without 
 *     specific prior written permission.

 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS 
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED 
 * TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR 
 * PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR 
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, 
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, 
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR 
 * PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF 
 * LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING 
 * NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS 
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
#ifndef BCOPYOPERATOR_H
#define BCOPYOPERATOR_H

#include <cassert>
#include "../common/Interfaces.h"
#include "../Wrappers/PosBasicBlock.h"

/**
 *
 * BCopyOperator high-level pseudocode:
 * Read in blocks using getNextBlock
 * Copy blocks num_copies times
 * Allow getNextValBlock to access copies through index argument
 */

class BCopyOperator : public Operator {

 public:
  // CONSTRUCTORS
  BCopyOperator(Operator *inOp_, int inColIndex_, int numParents);

  virtual ~BCopyOperator();
  
  // Operator interface
  virtual Block* getNextValBlock(int colIndex_);	
  virtual PosBlock* getNextPosBlock(int colIndex_);
  virtual PosBlock* getNextPosBlock(int colIndex_, int val_);
	inline virtual int getLastPosition() { return m_input->getLastPosition(); };
  
	protected:

  // INPUT STATE
  Operator *m_input;     // input operator
  int m_ColIndex;        // index of input column
  Block* inputBlock;
  PosBlock* inputPBlock;
  
  // OUTPUT STATE
  bool* m_iskBlockConsumed;   // whether the kth block has been consumed by Operator above
  Block **m_BlockOut;   // output agg block
  PosBlock **m_PBlockOut;   // output agg block

 private:
  int numParents_;

  //bool m_areInputBlocksInitialized;

  // initializes the BCopyOperator
  void init();

  // initializes the input blocks to the BCopyOperator
  //bool initInputValBlocks();
  //bool initInputPosBlocks();

  void generateBlocks();
  void generatePBlocks();
  
};

#endif
