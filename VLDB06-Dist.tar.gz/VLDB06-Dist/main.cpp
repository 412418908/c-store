/*
Copyright (c) 2005, Massachusetts Institute of Technology, Brown University, Brandeis University, and University of Massachusetts, Boston. All rights reserved.

Redistribution and use in source and binary forms, with or without modification, are permitted provided that the following conditions are met:

Redistributions of source code must retain the above copyright notice, this list of conditions and the following disclaimer. Redistributions in binary form must reproduce the above copyright notice, this list of conditions and the following disclaimer in the documentation and/or other materials provided with the distribution. Neither the name of the nor the names of its contributors may be used to endorse or promote products derived from this software without specific prior written permission. THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE. 
*/
#include <errno.h>
#include <iostream>
#include <stddef.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

////////////////////////////
//Declare workload paths here

#include "workload/tpch/tpch.h"

/////////////////////////
// Enviromental variables

char* TPCH_DATA_PATH;
int IO_DEPTH;
int SCAN_BUFFER;
int BLOCK_SIZE;
int PAGE_SIZE;


using std::cout;
using std::cerr;
using std::endl;

int dbMTPCH_setup();
int dbMTPCH_run();

void query();

void usage() {
  cerr << "Rstore usage: rstore [-s] [-r]" << endl;
  cerr << "                      -s setup a micro-TPCH database" << endl;
  cerr << "                      -r run a micro-TPCH query" << endl;
}

int main(int argc, char * argv[]) {
  int setup_flag, run_flag;
  setup_flag = run_flag = 0;
 
  if (argc < 2) {
    usage();
    return 0;
  }
  if (!strcmp(argv[1], "-s")) {
    setup_flag = 1;
  }
  else if (!strcmp(argv[1], "-r")) {
    run_flag = 1;
  }
  else {
    usage();
    return 0;
  } 

  // get environmental parameters
  char* s = getenv("SCAN_BUFFER");
  if (s == NULL) 
    SCAN_BUFFER = DEFAULT_SCAN_BUFFER; // in tuple.h
  else 
    SCAN_BUFFER = atoi(s);
  cerr << SCAN_BUFFER << " bytes scan buffer" << endl;

  char* s2 = getenv("BLOCK_SIZE");
  if (s2 == NULL) 
    BLOCK_SIZE = DEFAULT_BLOCK_SIZE; // in tuple.h
  else
    BLOCK_SIZE = atoi(s2);
  cerr << BLOCK_SIZE << " entries block size " << endl;
  
  char* s3 = getenv("PAGE_SIZE");
  if (s3 == NULL) 
     PAGE_SIZE = DEFAULT_PAGE_SIZE; // in tuple.h
  else 
     PAGE_SIZE = atoi(s3);
  cerr << PAGE_SIZE << " bytes page size " << endl;

  char* s4 = getenv("IO_DEPTH");
  if (s4 == NULL)
    IO_DEPTH = DEFAULT_IO_DEPTH; // in tuple.h
  else
    IO_DEPTH = atoi(s4);
  cerr << IO_DEPTH << " I/O depth size " << endl;

  // sanity checks
  if (SCAN_BUFFER % PAGE_SIZE) {
    cerr << "oops! SCAN_BUFFER is not multiple of PAGE_SIZE" << endl;
    exit(1);
  }

  //set up path to tables
  TPCH_DATA_PATH=getenv("TPCH_DATA_PATH");
  if (TPCH_DATA_PATH == NULL)
    TPCH_DATA_PATH=".";
  cerr << "Data path: " << TPCH_DATA_PATH << endl;

  int ret = 0;

  // Setup database
  if (setup_flag)
    ret = dbMTPCH_setup();
   
  // Run a query
  if (run_flag == 1)
    ret = dbMTPCH_run();

  // Finished
  if (ret >= 0)
    cerr << "Success!" << endl;
  else
    cerr << "Failed!" << endl;
  return 0;
} 

// Setup a micro-TPCH database
int dbMTPCH_setup() {
  //create_tpch(LINEITEM, "L-1", 0);
  //create_tpch(LINEITEM, "L-Z-1", 1);
  //create_tpch_cstore(LINEITEM, L_SHIPDATE, "L_SHIPDATE-1", 0);
  //create_tpch_cstore(LINEITEM, L_SHIPDATE, "L_SHIPDATE-Z-1", 1);
  //create_tpch_cstore(LINEITEM, L_ORDERKEY, "L_ORDERKEY-1", 0);
#if 0
  create_tpch_cstore(LINEITEM, L_PARTKEY, "L_PARTKEY-1", 0);
  create_tpch_cstore(LINEITEM, L_SUPPKEY, "L_SUPPKEY-1", 0);
  create_tpch_cstore(LINEITEM, L_LINENUMBER, "L_LINENUMBER-1", 0);
  create_tpch_cstore(LINEITEM, L_QUANTITY, "L_QUANTITY-1", 0);
  create_tpch_cstore(LINEITEM, L_EXTENDEDPRICE, "L_EXTENDEDPRICE-1", 0);
  create_tpch_cstore(LINEITEM, L_DISCOUNT, "L_DISCOUNT-1", 0);
  create_tpch_cstore(LINEITEM, L_TAX, "L_TAX-1", 0);
  create_tpch_cstore(LINEITEM, L_RETURNFLAG, "L_RETURNFLAG-1", 0);
  create_tpch_cstore(LINEITEM, L_LINESTATUS, "L_LINESTATUS-1", 0);
  create_tpch_cstore(LINEITEM, L_COMMITDATE, "L_COMMITDATE-1", 0);
  create_tpch_cstore(LINEITEM, L_RECEIPTDATE, "L_RECEIPTDATE-1", 0);
  create_tpch_cstore(LINEITEM, L_SHIPINSTRUCT, "L_SHIPINSTRUCT-1", 0);
  create_tpch_cstore(LINEITEM, L_SHIPMODE, "L_SHIPMODE-1", 0);
  create_tpch_cstore(LINEITEM, L_COMMENT, "L_COMMENT-1", 0);
#endif
  //create_tpch_rstore(ORDERS, "O", 0);
  //create_tpch_rstore(ORDERS, "O-Z", 1);
  //create_tpch_cstore(ORDERS, O_ORDERSTATUS, "O_ORDERSTATUS-40-Z", 1);
  //create_tpch_cstore(ORDERS, O_ORDERDATE, "O_ORDERDATE-40-Z", 1);
  //create_tpch_cstore(ORDERS, O_ORDERKEY, "O_ORDERKEY-40-Z", 1);
  //create_tpch_cstore(ORDERS, O_ORDERPRIORITY, "O_ORDERPRIORITY-40-Z", 1);
  //create_tpch_cstore(ORDERS, O_SHIPPRIORITY, "O_SHIPPRIORITY-40-Z", 1);
  return 0;
}

// Run a micro-TPCH query
int dbMTPCH_run() {
#ifdef USE_PAPI
  //+ setting up PAPI
  util* u = new util();
  u->init_PAPI();
  u->setup_PAPI_event();
  //-

  //+ starting PAPI
  u->start_PAPI_event();
  long_long start_usec = u->get_usec();
  long_long start_cyc = u->get_cycle();
  //-
#endif

  query(); 

#ifdef USE_PAPI
  //+ output PAPI
  u->read_PAPI_event();
  u->print_PAPI_event();
  long_long elapsed_usec = u->get_usec() - start_usec;
  long_long elapsed_cyc = u->get_cycle() - start_cyc;
  cout << elapsed_usec << endl << endl;
  cerr << "elapsed time in usec:" << elapsed_usec << endl;
  cerr << "elapsed cycles:" << elapsed_cyc << endl;
  //-
  delete u;
#endif
  return 0;
}
