/*
Copyright (c) 2005, Massachusetts Institute of Technology, Brown University, Brandeis University, and University of Massachusetts, Boston. All rights reserved.

Redistribution and use in source and binary forms, with or without modification, are permitted provided that the following conditions are met:

Redistributions of source code must retain the above copyright notice, this list of conditions and the following disclaimer. Redistributions in binary form must reproduce the above copyright notice, this list of conditions and the following disclaimer in the documentation and/or other materials provided with the distribution. Neither the name of the nor the names of its contributors may be used to endorse or promote products derived from this software without specific prior written permission. THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE. 
*/
#include "fscanR.h"

#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <string>
#include <stdlib.h>

using namespace std;
using std::cout;
using std::cerr;
using std::endl;

///////////////////////////////////////////////////////////
// Constructor/Destructor for fscanR operator

fscanR::fscanR(char* dbFile, scan_obj_t* sObj)
       : operator_t(NULL, NULL),
         scanObj_(sObj) {
  
  // open file for read and get its size
  string inFile;
  string data_path = TPCH_DATA_PATH;
  inFile = data_path + "/" + dbFile;
  fildes_ = open(inFile.c_str(), O_RDONLY | O_DIRECT | O_LARGEFILE);
  if (fildes_ < 0) {
    cerr << "error in opening file!" << endl;
    exit(1);
  }
  struct stat64 stat_buf;
  fstat64(fildes_, &stat_buf);
  fileSize_ = stat_buf.st_size;
  fileOffset_ = 0;

  // setup buffers for reading
  buffers_ = new void*[IO_DEPTH];
  for (int i = 0; i < IO_DEPTH; i++) {
    posix_memalign(&buffers_[i], 512, SCAN_BUFFER);
  }
  bufIndex_ = 0;
  bufOffset_ = 0;
  currentRow_ = 0;
  numRows_ = 0;
  
  // setup AIO structures
  iocbpp_ = new struct iocb**[IO_DEPTH];
  evtp_ = new struct io_event*[IO_DEPTH];
  ctx_ = new io_context_t[IO_DEPTH];

  for (int i = 0; i < IO_DEPTH; i++) {
    iocbpp_[i] = new struct iocb*[1];
    iocbpp_[i][0] = new struct iocb;
    evtp_[i] = new struct io_event;
    ctx_[i] = 0;
    if (io_setup(1, &ctx_[i])) {
      cerr << "error in setting up aio!" << endl;
      exit(1);
    }
  }
  AIO_done_ = false;
  
  // setup output tuple buffer
  outTuples_ = new tuple_t[BLOCK_SIZE];
  outTupleBlock_ =  new tuple_block_t(outTuples_);
  for (int i = 0; i < BLOCK_SIZE; i++) {
    outTuples_[i].data = new char[scanObj_->tuple_len];
    outTuples_[i].len = scanObj_->tuple_len;
  }
} // fscanR constructor


fscanR::~fscanR() { 
 
  //close file
  close(fildes_);

  if (scanObj_)
    delete scanObj_;
}


///////////////////////////////////////////////////////////
// Iterator interface for fscanR

tuple_block_t* fscanR::get_next() {
  int ret;
  // local storage for currently read tuple
  tuple_t tuple;

  if (done_)
    return NULL;

  // Initialization of scan
  if (!init_) {
    init_ = true;

    // get input:
    // issue IO_DEPTH requests and collect the first
    for (int i = 0; i < IO_DEPTH; i++) {
      io_prep_pread(iocbpp_[i][0], fildes_, buffers_[i], SCAN_BUFFER, fileOffset_);
      io_submit(ctx_[i], 1, iocbpp_[i]);
      fileOffset_ += SCAN_BUFFER;
      if (fileOffset_ >= fileSize_) {
        // we reached end-of-file
        AIO_done_ = true;
        break;
      }
    }
    if ((ret = io_getevents(ctx_[0], 1, 1, evtp_[0], NULL)) != 1) {
      cerr << ret << " events returned!" << endl;
      exit(1);
    }
    buf_ = buffers_[0];
    bufIndex_ = 1;
     // get number of rows in current page
    numRows_ = *((int*)(buf_));
    if (numRows_ <= 0) {
      cerr << "invalid number of rows in first page -- exiting" << endl;
      exit(1);
    }
  }

  // reset number of tuples written and current position
  // in the output tuple buffer (we re-use the memory allocated)
  outTupleBlock_->reset();

  int num = 0;
  tuple.len = scanObj_->in_tuple_len;
  bool done = true;

  while (1) {

    // check if we consumed the entire page
    if (currentRow_ == numRows_) {
      bufOffset_ += PAGE_SIZE;
      currentRow_ = 0;

      // check if we consumed the entire scan buffer  
      if (!(bufOffset_ % SCAN_BUFFER)) {

        //check if we finished reading all IO_DEPTH requests
        if (bufOffset_ >= SCAN_BUFFER * IO_DEPTH) {
          if (fileOffset_ >= fileSize_) {
            // we reached end-of-file
            AIO_done_ = true;
            break;
          }
          else {
            // submit new AIO requests
            for (int i = 0; i < IO_DEPTH; i++) {
              io_prep_pread(iocbpp_[i][0], fildes_, buffers_[i], SCAN_BUFFER, fileOffset_);
              io_submit(ctx_[i], 1, iocbpp_[i]);
              fileOffset_ += SCAN_BUFFER;
              if (fileOffset_ >= fileSize_) {
                // we reached end-of-file
                AIO_done_ = true;
                break;
              }
            }
            // collect 1st AIO, set current buf, 
            if ((ret = io_getevents(ctx_[0], 1, 1, evtp_[0], NULL)) != 1) {
              cerr << ret << " events returned!" << endl;
              exit(1);
            }
            buf_ = buffers_[0];
            bufIndex_ = 1;
            bufOffset_ = 0;
          }
        } // check if consumed all IO_DEPTH buffers
        else {
          // collect from previous AIO, set current buf,
          if ((ret = io_getevents(ctx_[bufIndex_], 1, 1, evtp_[bufIndex_], NULL)) != 1) {
            cerr << ret << " events returned!" << endl;
            exit(1);
          }
          buf_ = buffers_[bufIndex_];
          ++bufIndex_;
        }
      } // check if scan buffer empty
      else {   
        // advance buf_ 
        buf_ = (void*)((char*)buf_ + PAGE_SIZE);
      }

      // get number of rows in current page
      numRows_ = *((int*)buf_); 
      // exit the loop, set done_=true if numRows_ <= 0
      if (numRows_ <= 0) {
        done_ = true;
        if (AIO_done_ == false) {
          cerr << "Found terminating page before setting AIO_done_ to true!" << endl;
        }
        break;
      }
    } // check if page was consumed
 
    // read values at current row
    tuple.data = (char*)scanObj_->get_value_p((char*)buf_, currentRow_);
    ++currentRow_;

    //apply predicate
    if (scanObj_->predicate(&tuple)) {

      //project (write projected tuple into outTuples_ array)
      scanObj_->project(&tuple, &outTuples_[num]);
      if (++num == BLOCK_SIZE) {
        done = false; 
        break;
      }
    }

  } // while(1)

  if (done) {
    done_ = true;
  } 

  tuple.data = NULL; // tuple is local
  outTupleBlock_->set_num(num);
  // return pointer to outTuples_ array
  return outTupleBlock_;
}
