/*
Copyright (c) 2005, Massachusetts Institute of Technology, Brown University, Brandeis University, and University of Massachusetts, Boston. All rights reserved.

Redistribution and use in source and binary forms, with or without modification, are permitted provided that the following conditions are met:

Redistributions of source code must retain the above copyright notice, this list of conditions and the following disclaimer. Redistributions in binary form must reproduce the above copyright notice, this list of conditions and the following disclaimer in the documentation and/or other materials provided with the distribution. Neither the name of the nor the names of its contributors may be used to endorse or promote products derived from this software without specific prior written permission. THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE. 
*/
#ifndef __OPERATOR_H
#define __OPERATOR_H

#include <string.h>
#include <stdlib.h>
#include <iostream>
#include <db_cxx.h>
#include "tuple.h"

// Base class for relational operators.
// For simplicity, we support only unary and binary operators,
// with unary operators having both children pointers pointing
// to a single child.

using std::cout;
using std::endl;

class operator_t {
public:
  operator_t(operator_t* l, operator_t* r);
  virtual ~operator_t();
  virtual tuple_block_t* get_next();
  virtual void init_operator();

protected:
  bool done_;
  bool init_;
  tuple_t* outTuples_;
  tuple_block_t* outTupleBlock_;
  tuple_block_t* leftCurrentBlock_;
  tuple_block_t* rightCurrentBlock_;
  tuple_t* leftCurrentTuple_;
  tuple_t* rightCurrentTuple_;
  operator_t* leftChild_;
  operator_t* rightChild_;
};


// Base classes for operator objects


///////////////////////////////////////////////////
// A base scan_obj performs no selection/projection

class scan_obj_t {
public:
  scan_obj_t(size_t t_len = 256, size_t in_len = 256, bool pass_thru = false)
      : tuple_len(t_len),
        in_tuple_len(in_len),
        pass_through(pass_thru)  {}
  // predicate always qualifies
  virtual bool predicate(tuple_t* tuple) {
    return true;
  }
  // projection simply copies all fields
  virtual void project(tuple_t* in_tuple, tuple_t* out_tuple) {
    out_tuple->len = in_tuple->len;
    memcpy(out_tuple->data, in_tuple->data, in_tuple->len);
    return;
  }
  // get_value_p (pointer) at a given pos from the input block
  virtual char* get_value_p(char* buf_, int pos) {
    return (buf_ + 4 + in_tuple_len * pos);
  }
  // combine merges 2 input tuples in a new one (column-scanning)
  virtual void combine(tuple_t* in_tuple1, tuple_t* in_tuple2, tuple_t* out_tuple) {
    out_tuple->len = in_tuple1->len + in_tuple2->len;
    memcpy(out_tuple->data, in_tuple1->data, in_tuple1->len);
    memcpy(out_tuple->data+in_tuple1->len, in_tuple2->data, in_tuple2->len);
    return;
  }
public:
  size_t tuple_len;
  size_t in_tuple_len;
  bool pass_through; // used in column-scanning
};


///////////////////////////////////////////////////////////////
// A base print_obj prints on screen only the length of a tuple

class print_obj_t {
public:
  virtual void print_tuple(tuple_t* tuple) {
    cout << "tuple of length " << tuple->len << endl;
  }
};

class merge_obj_t {
public:
  merge_obj_t(size_t t_len = 256) : tuple_len(t_len) {}
  // compare assumes we only use one sorted int attribute
  virtual tuple_t* compare(tuple_t* l, tuple_t* r) {
    if (*((int*)(l->data)) <= *((int*)(r->data)))
      return l;
    else
      return r;
  }
  virtual void copy(tuple_t* in_tuple, tuple_t* out_tuple) {
    memcpy(out_tuple->data, in_tuple->data, in_tuple->len);
    return;
  }
public:
  size_t tuple_len;
};

class write_obj_t {
public:
  write_obj_t(size_t t_len = 256) : tuple_len(t_len) {}

public:
  size_t tuple_len;
};
#endif // __OPERATOR_H
