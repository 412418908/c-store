/*
Copyright (c) 2005, Massachusetts Institute of Technology, Brown University, Brandeis University, and University of Massachusetts, Boston. All rights reserved.

Redistribution and use in source and binary forms, with or without modification, are permitted provided that the following conditions are met:

Redistributions of source code must retain the above copyright notice, this list of conditions and the following disclaimer. Redistributions in binary form must reproduce the above copyright notice, this list of conditions and the following disclaimer in the documentation and/or other materials provided with the distribution. Neither the name of the nor the names of its contributors may be used to endorse or promote products derived from this software without specific prior written permission. THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE. 
*/
#ifndef __FSCANR_H
#define __FSCANR_H

#include "operator.h"
#include "util.h"
#include <db_cxx.h>

#include <libaio.h>

class fscanR : public operator_t {
public:
  fscanR(char* dbFile, scan_obj_t* s_obj);
  virtual ~fscanR();

  tuple_block_t* get_next();
  void init_operator() {}

private:
  scan_obj_t* scanObj_; // scan object associated with this scan

  void** buffers_;

  void* buf0_; // pointers to the two input buffers
  void* buf1_;
  void* buf_; // helper buffer pointer
  int bufOffset_; // current page offset within the buffer
  int bufIndex_; // 0 or 1, selecting current buffer
  int currentRow_; // current row number within a page
  int numRows_; // number of rows in current page

  int fildes_; // file descriptor
  long long fileSize_; // size of the scanned file
  long long fileOffset_; // offset used when scanning file
  
  io_context_t ctx0_; // AIO structures ...
  io_context_t ctx1_;
  struct iocb** iocbpp0_;
  struct iocb** iocbpp1_;
  struct io_event* evtp0_;
  struct io_event* evtp1_; // ... AIO structures

  io_context_t* ctx_;
  struct iocb*** iocbpp_;
  struct io_event** evtp_;

  bool AIO_done_; // signal when the entire file is read
 
};

#endif // __FSCANR_H
