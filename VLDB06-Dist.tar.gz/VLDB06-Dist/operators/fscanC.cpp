/*
Copyright (c) 2005, Massachusetts Institute of Technology, Brown University, Brandeis University, and University of Massachusetts, Boston. All rights reserved.

Redistribution and use in source and binary forms, with or without modification, are permitted provided that the following conditions are met:

Redistributions of source code must retain the above copyright notice, this list of conditions and the following disclaimer. Redistributions in binary form must reproduce the above copyright notice, this list of conditions and the following disclaimer in the documentation and/or other materials provided with the distribution. Neither the name of the nor the names of its contributors may be used to endorse or promote products derived from this software without specific prior written permission. THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE. 
*/
#include "fscanC.h"

#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h> 
#include <string>
#include <stdlib.h>

AIOlist_t* AIOlist;

using namespace std;  
using std::cout;
using std::cerr;
using std::endl;

///////////////////////////////////////////////////////////
// Constructor/Destructor for fscanC operator

fscanC::fscanC(char* dbFile, fscanC* scanChild, scan_obj_t* sObj)
       : operator_t(NULL, scanChild),
         scanObj_(sObj) {
  
  // open file for read and get its size
  string inFile;
  string data_path = TPCH_DATA_PATH;
  inFile = data_path + "/" + dbFile;
  fildes_ = open(inFile.c_str(), O_RDONLY | O_DIRECT | O_LARGEFILE);
  if (fildes_ < 0) {
    cerr << "error in opening file!" << endl;
    exit(1);
  }
  struct stat64 stat_buf;
  fstat64(fildes_, &stat_buf);
  fileSize_ = stat_buf.st_size;
  fileOffset_ = 0;

  // setup double buffers for reading
  buffers0_ = new void*[IO_DEPTH];
  buffers1_ = new void*[IO_DEPTH];
  for (int i = 0; i < IO_DEPTH; i++) {
    posix_memalign(&buffers0_[i], 512, SCAN_BUFFER);
    posix_memalign(&buffers1_[i], 512, SCAN_BUFFER);
  }
  bufIndex_ = 0;
  doubleBufIndex_ = 0;
  bufOffset_ = 0;
  currentAttr_ = 0;
  numAttrs_ = 0;
  currentPos_ = 0;
  maxPosInPage_ = 0;

  // setup AIO structures
  iocbpp0__ = new struct iocb**[IO_DEPTH];
  iocbpp1__ = new struct iocb**[IO_DEPTH];
  evtp0__ = new struct io_event*[IO_DEPTH];
  evtp1__ = new struct io_event*[IO_DEPTH];
  AIO_done_ = false;
  ctx0__ = new io_context_t[IO_DEPTH];
  ctx1__ = new io_context_t[IO_DEPTH];
  for (int i = 0; i < IO_DEPTH; i++) {
    ctx0__[i] = 0;
    ctx1__[i] = 0;
    if (io_setup(1, &ctx0__[i])) {
      cerr << "error in setting up aio!" << endl;
      exit(1);
    }
    if (io_setup(1, &ctx1__[i])) {
      cerr << "error in setting up aio!" << endl;
      exit(1);
    }
    iocbpp0__[i] = new struct iocb*[1];
    iocbpp0__[i][0] = new struct iocb;
    iocbpp1__[i] = new struct iocb*[1];
    iocbpp1__[i][0] = new struct iocb;
    evtp0__[i] = new struct io_event;
    evtp1__[i] = new struct io_event;
  }

  // setup output tuple buffer
  if (scanObj_->pass_through) {
    // "pass_through" means this column doesn't do any filtering
    outTuples_ = NULL;
    outTupleBlock_ = NULL;
  }
  else {
    outTuples_ = new tuple_t[BLOCK_SIZE];
    outTupleBlock_ =  new tuple_block_t(outTuples_);
    for (int i = 0; i < BLOCK_SIZE; i++) {
      outTuples_[i].data = new char[scanObj_->tuple_len];
      outTuples_[i].len = scanObj_->tuple_len;
    }
  }

  // if this is the last node, rightCurrentTuple_ holds the currentPos_
  if (!rightChild_) 
    rightCurrentTuple_ = new tuple_t(sizeof(int), (char*)(&currentPos_));

  // last node is also responsible for creating/destroying AIOlist
  if (!rightChild_)
    AIOlist = new AIOlist_t;

  // add our first AIO request to the queue
  // (it will also submit it, if disk is idle)

  int num = 0;
  for (num = 0; num < IO_DEPTH; num++) {
    io_prep_pread(iocbpp0__[num][0], fildes_, buffers0_[num], SCAN_BUFFER, fileOffset_);
    fileOffset_ += SCAN_BUFFER;
    if (fileOffset_ >= fileSize_) {
      // we reached end-of-file
      AIO_done_ = true;
      ++num;
      break;
    }
  }
  AIOlist->insertV(ctx0__, num, iocbpp0__, evtp0__);
}


fscanC::~fscanC() {

  //close file
  close(fildes_);

  if (scanObj_)
    delete scanObj_;
}


///////////////////////////////////////////////////////////
// Iterator interface for fscanC

tuple_block_t* fscanC::get_next() {
  int num;
  // local storage for currently read tuple
  tuple_t tuple;

  if (done_) {
    // set up correctly for destructor
    if (scanObj_->pass_through) {
      outTupleBlock_ = NULL;
      outTuples_ = NULL;
    }
    return NULL;
  }

  // Initialization of scan
  if (!init_) {
    init_ = true;

    // get input from other columns (positions + data)
    if (rightChild_ && !(rightCurrentBlock_ = rightChild_->get_next())) {
      done_ = true;
      return NULL;
    }

    // get input from this column (blocking call)
    AIOlist->collectONE(ctx0__, bufIndex_);
    buf_ = buffers0_[0];
    bufIndex_ = 1;
   
    // get number of attributes in current page
    numAttrs_ = *((int*)(buf_));
    maxPosInPage_ = numAttrs_;
    if (numAttrs_ <= 0) {
      cerr << "invalid number of attributes in first page -- exiting" << endl;
      exit(1);
    }

    // prepare and insert at the waiting list a set of requests for our next AIO
    num = 0;
    if (!AIO_done_) {
      for (num = 0; num < IO_DEPTH; num++) {
        io_prep_pread(iocbpp1__[num][0], fildes_, buffers1_[num], SCAN_BUFFER, fileOffset_);
        fileOffset_ += SCAN_BUFFER;
        if (fileOffset_ >= fileSize_) {
          // we reached end-of-file
          AIO_done_ = true;
          ++num;
          break;
        }
      }
      AIOlist->insertV(ctx1__, num, iocbpp1__, evtp1__);
    }
  } // if init_

  // if not pass_through, reset number of tuples written and current position
  // in the output tuple buffer (we re-use the memory allocated)
  if (!scanObj_->pass_through) {
    outTupleBlock_->reset();
  }
  else {
    outTupleBlock_ = rightCurrentBlock_;
    outTuples_ = rightCurrentBlock_-> get_tuples();
  }

  int localPos = 0;
  int ind = 0;
  tuple.len = scanObj_->in_tuple_len;
  bool done = true;

  // do the following for an intermediate scan node
  if (rightChild_) {

    // while the scan child provides a block of tuples
    while (rightCurrentBlock_) {
 
      // while the scan child's block is not empty
      while (rightCurrentTuple_ = rightCurrentBlock_->get()) {

        // get next position to read data
        currentPos_ = *((int*)rightCurrentTuple_->data);

        // if needed, keep consuming pages until we reach currentPos_
        while (currentPos_ >= maxPosInPage_) {

          // let's advance 1 page
          bufOffset_ += PAGE_SIZE;

          // every 100 pages, we check te AIOlist for AIO completions
          if (!(bufOffset_ % (100 * PAGE_SIZE))) {
            AIOlist->checkAIOV();
          }

          // check if we consumed the entire scan buffer
          if (!(bufOffset_ % SCAN_BUFFER)) {

            //check if we finished reading all IO_DEPTH requests
            if (bufOffset_ >= SCAN_BUFFER * IO_DEPTH) {
              if (fileOffset_ >= fileSize_) {
                // we reached end-of-file 
                AIO_done_= true;
              }
              else {
                // submit new set of AIO requests
                num = 0;
                for (num = 0; num < IO_DEPTH; num++) {
                  if (doubleBufIndex_ == 0)
                    io_prep_pread(iocbpp0__[num][0], fildes_, buffers0_[num], SCAN_BUFFER, fileOffset_);
                  else
                    io_prep_pread(iocbpp1__[num][0], fildes_, buffers1_[num], SCAN_BUFFER, fileOffset_);
                  fileOffset_ += SCAN_BUFFER;
                  if (fileOffset_ >= fileSize_) {
                    // we reached end-of-file
                    AIO_done_ = true;
                    ++num;
                    break;
                  }
                }
                if (doubleBufIndex_ == 0)
                  AIOlist->insertV(ctx0__, num, iocbpp0__, evtp0__);
                else
                  AIOlist->insertV(ctx1__, num, iocbpp1__, evtp1__);
              }
              // switch buffers, read 1st one
              if (doubleBufIndex_ == 0) {
                AIOlist->collectONE(ctx1__, 0);
                buf_ = buffers1_[0];
              }
              else {
                AIOlist->collectONE(ctx0__, 0);
                buf_ = buffers0_[0];
              }
              bufIndex_ = 1;
              doubleBufIndex_ = (doubleBufIndex_ + 1) % 2;                
              bufOffset_ = 0;
            } // check if consumed all IO_DEPTH buffers
            else {
              // collect from previous AIO, set current buf,
              if(doubleBufIndex_ == 0) {
                AIOlist->collectONE(ctx0__, bufIndex_);
                buf_ = buffers0_[bufIndex_];
              }
              else {
                AIOlist->collectONE(ctx1__, bufIndex_);
                buf_ = buffers1_[bufIndex_];
              }
              ++bufIndex_;
            }
          } // check if scan buffer empty
          else {
            // advance buf_
            buf_ = (void*)((char*)buf_ + PAGE_SIZE);
          }

          // get number of attributes in current page
          numAttrs_ = *((int*)(buf_));
        
          // numAttrs_ should not be <=0 for an intermediate node
          if (numAttrs_ <= 0) {
            cerr << "Intermediate node read 0 Attributes -- exiting" << endl;
            exit(1);
          } 

          // update maxPosInPage_
          maxPosInPage_ += numAttrs_;

        } // while (currentPos_ >= maxPosInPage_)

        // update localPos and read current value
        localPos = numAttrs_ - (maxPosInPage_ - currentPos_);
        tuple.data = (char*)scanObj_->get_value_p((char*)buf_, localPos);
       
        //apply predicate
        if (scanObj_->predicate(&tuple)) {
       
          //project (adds current value to existing tuple, copies into out_tuples)
          scanObj_->combine(rightCurrentTuple_, &tuple, &outTuples_[ind]);
 
          if (++ind == BLOCK_SIZE) {
            done = false; 
            break;
          }
        } // if predicate true
      } // while (rightCurrentTuple_ = rightCurrentBlock_->get())

      if (done == false)
        break;
          
      // get next block of tuples from child node
      rightCurrentBlock_ = rightChild_->get_next();

    } // while (rightCurrentBlock_)

  } //if (rightChild_)
  else { 
    // this is the last scan node
    while (1) {

      // check if we consumed the entire page
      if (currentAttr_ == numAttrs_) {
        bufOffset_ += PAGE_SIZE;
        currentAttr_ = 0;

        // every 100 pages, we check te AIOlist for AIO completions
        if (!(bufOffset_ % (100 * PAGE_SIZE))) {
          AIOlist->checkAIOV();
        }
 
        // check if we consumed the entire scan buffer  
        if (!(bufOffset_ % SCAN_BUFFER)) { 
          //check if we finished reading all IO_DEPTH requests
          if (bufOffset_ >= SCAN_BUFFER * IO_DEPTH) {
            if (fileOffset_ >= fileSize_) {
              // we reached end-of-file
              AIO_done_ = true;
            }  
            else {
              // submit new set of AIO requests
              num = 0;
              for (num = 0; num < IO_DEPTH; num++) {
                if (doubleBufIndex_ == 0)
                  io_prep_pread(iocbpp0__[num][0], fildes_, buffers0_[num], SCAN_BUFFER, fileOffset_);
                else
                  io_prep_pread(iocbpp1__[num][0], fildes_, buffers1_[num], SCAN_BUFFER, fileOffset_);
                fileOffset_ += SCAN_BUFFER;
                if (fileOffset_ >= fileSize_) {
                  // we reached end-of-file
                  AIO_done_ = true;
                  ++num;
                  break;
                }
              }
              if (doubleBufIndex_ == 0) 
                AIOlist->insertV(ctx0__, num, iocbpp0__, evtp0__);
              else 
                AIOlist->insertV(ctx1__, num, iocbpp1__, evtp1__);
            }
            // switch buffers, read 1st one
            if (doubleBufIndex_ == 0) {
              AIOlist->collectONE(ctx1__, 0);
              buf_ = buffers1_[0];
            }          
            else {
              AIOlist->collectONE(ctx0__, 0);       
              buf_ = buffers0_[0];
            }
            bufIndex_ = 1;
            doubleBufIndex_ = (doubleBufIndex_ + 1) % 2;
            bufOffset_ = 0;
          } // check if consumed all IO_DEPTH buffers
          else {
            // collect from previous AIO, set current buf,
            if(doubleBufIndex_ == 0) {
              AIOlist->collectONE(ctx0__, bufIndex_);
              buf_ = buffers0_[bufIndex_];
            }
            else {
              AIOlist->collectONE(ctx1__, bufIndex_);
              buf_ = buffers1_[bufIndex_];
            }
            ++bufIndex_;
          }
        } // check if scan buffer empty
        else {
          // advance buf_ 
          buf_ = (void*)((char*)buf_ + PAGE_SIZE);
        }

        // get number of attributes in current page
        numAttrs_ = *((int*)(buf_));

        // exit the loop, set done_=true if numAttrs_ <= 0
        if (numAttrs_ <= 0) {
          done_ = true;
          if (AIO_done_ == false) {
            cerr << "Found terminating page before setting AIO_done_ to true!" << endl;
          }
          break;
        }
        // update maxPosInPage_
        maxPosInPage_ += numAttrs_;
      } // check if page was consumed

      // read current value
      tuple.data = (char*)scanObj_->get_value_p((char*)buf_, currentAttr_);

      //apply predicate
      if (scanObj_->predicate(&tuple)) {

        // update currentPos_ (rightCurrentTuple_.data points already to that value)
        currentPos_ = (maxPosInPage_ - numAttrs_) + currentAttr_;
        //project (adds current value to existing tuple, copies into out_tuples)
        scanObj_->combine(rightCurrentTuple_, &tuple, &outTuples_[ind]);

        if (++ind == BLOCK_SIZE) {
          done = false;
          ++currentAttr_;
          break;
        }
      } // if predicate true
      ++currentAttr_;
    } // while (1)
  } // if last scan node

  if (done) {
    done_ = true;
  } 
  // set up correctly for destructor
  tuple.data = NULL; 
  
  // if we pass through the pointer to outTupleBlock_
  // we need to reset the internal position to 0 (ind remains the same)
  if (scanObj_->pass_through) {
    if (outTupleBlock_) 
      outTupleBlock_->reset_pos();
  }
  // ..otherwise, we set the number of tuples in the block (pos is already 0)
  else {
    outTupleBlock_->set_num(ind);
  } 

  return outTupleBlock_;
}
