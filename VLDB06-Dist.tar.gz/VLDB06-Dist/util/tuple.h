/*
Copyright (c) 2005, Massachusetts Institute of Technology, Brown University, Brandeis University, and University of Massachusetts, Boston. All rights reserved.

Redistribution and use in source and binary forms, with or without modification, are permitted provided that the following conditions are met:

Redistributions of source code must retain the above copyright notice, this list of conditions and the following disclaimer. Redistributions in binary form must reproduce the above copyright notice, this list of conditions and the following disclaimer in the documentation and/or other materials provided with the distribution. Neither the name of the nor the names of its contributors may be used to endorse or promote products derived from this software without specific prior written permission. THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*/
#ifndef __TUPLE_H
#define __TUPLE_H

#include <stdlib.h>

#define DEFAULT_PAGE_SIZE 4096
#define DEFAULT_BLOCK_SIZE 100
#define DEFAULT_SCAN_BUFFER 128 * 1024
#define DEFAULT_IO_DEPTH 48

extern int PAGE_SIZE;
extern int BLOCK_SIZE;
extern int SCAN_BUFFER;
extern int IO_DEPTH;
extern char* TPCH_DATA_PATH;

// class tuple_t: simple representation of a tuple

class tuple_t {
public:
  ~tuple_t() { if(data) delete[] data; }
  tuple_t(size_t l = 0, char* d = NULL)
      : len(l),
        data(d) {}
  size_t len;
  char* data;
};

// class tuple_block_t: a block of tuple pointers (stored in tuples_)
// tuple_block_t is NOT responsible for allocating or destroying tuples

class tuple_block_t {
public:
  ~tuple_block_t() {}
  tuple_block_t(tuple_t* t = NULL)
      : pos_(0),
        num_(0),
        tuples_(t) {}
  void reset_pos();
  void set_num(int n);
  void reset();
  tuple_t* get_tuples() {return tuples_;}
  tuple_t* get();

private:
  int pos_;
  int num_;
  tuple_t* tuples_;
};

#endif // __TUPLE_H
