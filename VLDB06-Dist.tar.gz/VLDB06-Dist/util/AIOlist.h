/*
Copyright (c) 2005, Massachusetts Institute of Technology, Brown University, Brandeis University, and University of Massachusetts, Boston. All rights reserved.

Redistribution and use in source and binary forms, with or without modification, are permitted provided that the following conditions are met:

Redistributions of source code must retain the above copyright notice, this list of conditions and the following disclaimer. Redistributions in binary form must reproduce the above copyright notice, this list of conditions and the following disclaimer in the documentation and/or other materials provided with the distribution. Neither the name of the nor the names of its contributors may be used to endorse or promote products derived from this software without specific prior written permission. THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE. 
*/
#ifndef __AIOLIST_H
#define __AIOLIST_H

// Uncomment the following to repeat the non- IO aggressive
// experiments described in the VLDB 2006 paper
//#define IO_NOT_AGGRESSIVE

#include <libaio.h>
#include <time.h>

struct AIOlistNode {
  struct AIOlistNode* next;
  io_context_t* ctx_idp;
  long nr;
  struct iocb** iocbpp;
  struct io_event* events;
  long nr_done;
}; 

struct AIOlistNodeV {
  struct AIOlistNodeV* next;
  io_context_t* ctx_idp;
  long nr;
  struct iocb*** iocbpp;
  struct io_event** events;
  long nr_done;
};


// class AIOlist_t

class AIOlist_t {
public:
  ~AIOlist_t() {}
  AIOlist_t();

  // insert AIO request at end of waiting queue
  // and if no one is in-flight, submit head of waiting queue
  int insert(io_context_t* ctx_idp, long nr,
             struct iocb** iocbpp, struct io_event* events);
  int insertV(io_context_t* ctx_idp, long nr,
             struct iocb*** iocbpp, struct io_event** events);

  // check if in-flight request is done (non-blocking)
  // if yes, move it to completed, and submit head of waiting list
  int checkAIO();
  int checkAIOV();

  // collects a specific AIO request
  // (could be completed, in-flight, or in any poeition at the waiting queue)
  void collect(io_context_t* ctx_idp);

  void collectONE(io_context_t* ctx_idp, int index);
 
private:
 struct AIOlistNode* waitp_;  // list holding AIO requests waiting for submission
 struct AIOlistNode* inFlightp_; // currenlty submitted AIO request 
 struct AIOlistNode* completedp_; // list with completed AIO requests

 struct AIOlistNodeV* waitp__;
 struct AIOlistNodeV* inFlightp__;
 struct AIOlistNodeV* completedp__;

 // submits to disk the head of the waiting list
 void submit_(); 
 void submitV_(); 
};

#endif // __AIOLIST_H
