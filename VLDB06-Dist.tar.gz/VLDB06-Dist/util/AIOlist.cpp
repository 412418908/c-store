/*
Copyright (c) 2005, Massachusetts Institute of Technology, Brown University, Brandeis University, and University of Massachusetts, Boston. All rights reserved.

Redistribution and use in source and binary forms, with or without modification, are permitted provided that the following conditions are met:

Redistributions of source code must retain the above copyright notice, this list of conditions and the following disclaimer. Redistributions in binary form must reproduce the above copyright notice, this list of conditions and the following disclaimer in the documentation and/or other materials provided with the distribution. Neither the name of the nor the names of its contributors may be used to endorse or promote products derived from this software without specific prior written permission. THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE. 
*/
#include "AIOlist.h"
#include <stdlib.h>
#include <iostream>

using std::cerr;
using std::endl;


AIOlist_t::AIOlist_t() {
  waitp_ = NULL;
  inFlightp_ = NULL;
  completedp_ = NULL;
  waitp__ = NULL;
  inFlightp__ = NULL;
  completedp__ = NULL;
}


// insert AIO request at end of waiting queue
// and if no one is in-flight, submit head of waiting queue

int AIOlist_t::insert(io_context_t* ctx_idp, long nr,
                    struct iocb** iocbpp, struct io_event* events) {
  struct AIOlistNode* np;
  struct AIOlistNode* node = new struct AIOlistNode;
  node->ctx_idp = ctx_idp;
  node->nr = nr;
  node->nr_done = 0;
  node->iocbpp = iocbpp;
  node->events = events;
  node->next = NULL;

  if (!waitp_) {
    waitp_ = node;
  }
  else {
    np = waitp_;
    while (np->next)
      np = np->next;
    np->next = node;
  }
  
  // if no one in flight, submit head
  if (inFlightp_ == NULL) {
    submit_();
    return 1;
  }
  return 0;
}


int AIOlist_t::insertV(io_context_t* ctx_idp, long nr,
                    struct iocb*** iocbpp, struct io_event** events) {
  struct AIOlistNodeV* np;
  struct AIOlistNodeV* node = new struct AIOlistNodeV;
  node->ctx_idp = ctx_idp;
  node->nr = nr;
  node->nr_done = 0;
  node->iocbpp = iocbpp;
  node->events = events;
  node->next = NULL;

  if (!waitp__) {
    waitp__ = node;
  }
  else {
    np = waitp__;
    while (np->next)
      np = np->next;
    np->next = node;
  }

  // if no one in flight, submit head
  if (inFlightp__ == NULL) {
    submitV_();
    return 1;
  }
  return 0;
}

void AIOlist_t::submitV_() {
  if (inFlightp__) {
    cerr << "I am not supposed to submit more than 1 set of AIOs" << endl;
    exit(1);
  }
  if (!waitp__) {
    cerr << "Nothing to submit for AIO" << endl;
    exit(1);
  }

  // submit AIO request set from head of waiting list
  inFlightp__ = waitp__;
  for (int i = 0; i < inFlightp__->nr; i++) {
    io_submit(inFlightp__->ctx_idp[i], 1, inFlightp__->iocbpp[i]);
  }
  // remove from waiting list
  waitp__ = waitp__->next;
  inFlightp__->next = NULL;
  return;
}



// submits to disk the head of the waiting queue

void AIOlist_t::submit_() {
  if (inFlightp_) {
    cerr << "I am not supposed to submit more than 1 set of AIOs" << endl;
    exit(1);
  }
  if (!waitp_) {
    cerr << "Nothing to submit for AIO" << endl;
    exit(1);
  }

  // submit AIO request set from head of waiting list
  inFlightp_ = waitp_;
  io_submit(*(waitp_->ctx_idp), waitp_->nr, waitp_->iocbpp);

  // remove from waiting list
  waitp_ = waitp_->next;
  inFlightp_->next = NULL;
  return;
}



void AIOlist_t::collectONE(io_context_t* ctx_idp, int index) {
  int ret;
  struct AIOlistNodeV* np = NULL;
  struct AIOlistNodeV* np2 = NULL;
  struct AIOlistNodeV* inFlightp2 = NULL;

  // 1. let's first see if the AIO to be collected is in flight

  if (inFlightp__ && inFlightp__->ctx_idp == ctx_idp) {
    // our set of AIO requests is in flight.
    // let's check now if the specific one is done
    if (index < inFlightp__->nr_done)  
      return;
    // still in flight -- we have to wait for it
    // if it's the last from the set, submit first the head of waiting queue (if not NULL)
    // and then wait until our request is done (timeout is NULL = infinite)
    if (inFlightp__->nr == 1) {
      inFlightp2 = inFlightp__;      
      inFlightp__ = NULL;
#ifndef IO_NOT_AGGRESSIVE
      if (waitp__)
        submitV_();
#endif
      if ((ret = io_getevents(ctx_idp[index], 1, 1,
                            inFlightp2->events[index], NULL)) != 1) {
         cerr << ret << " events returned!" << endl;
         exit(1);
      }
#ifdef IO_NOT_AGGRESSIVE
      if (waitp__)
        submitV_();
#endif
      delete inFlightp2;
      return;
    }
    else { // it's not the last from the set, so no other submissions
      if ((ret = io_getevents(ctx_idp[index], 1, 1,
                            inFlightp__->events[index], NULL)) != 1) {
         cerr << ret << " events returned!" << endl;
         exit(1);
      }
      ++inFlightp__->nr_done;
      --inFlightp__->nr;
      return;
    }
  } // if set is in-flight


  // 2. let's see if the AIO is in completed list
  
  if (completedp__) {
    if (completedp__->ctx_idp == ctx_idp) {
      if (completedp__->nr_done != index + 1)
        return;
      np = completedp__;
      completedp__ = completedp__->next;
      delete np;
      return;
    }
    np = completedp__;
    while(np->next) {
      if (np->next->ctx_idp == ctx_idp) {
        np2 = np->next;
        if (np2->nr_done != index + 1)
          return;
        np->next = np->next->next;
        delete np2;
        return;
      }
      np = np-> next;
    }
  }


  // 3. the AIO request is still in waiting queue:
  //    submit our AIO, collect the in flight one, and then ours

  if (index != 0) {
    cerr << "our set of requests is still in queue," << endl
         << "but we are trying to collect a request different than the 1st" << endl;
    exit(1);
  }
  if (!inFlightp__ || !waitp__) {
    cerr << "collect called with no in-flight or waiting request!" << endl;
    exit(1);
  }
#ifdef IO_NOT_AGGRESSIVE
  // collect first the in-flight set of requests
  for (int i = 0; i < inFlightp__->nr; i++) {
    if ((ret = io_getevents(inFlightp__->ctx_idp[inFlightp__->nr_done], 1, 1,
                            inFlightp__->events[inFlightp__->nr_done], NULL)) != 1) {
      cerr << ret << " events returned!" << endl;
      exit(1);
    }
    ++inFlightp__->nr_done;
   }
  inFlightp__->nr = 0;
  // move it to completed
  if (!completedp__) {
    completedp__ = inFlightp__;
  }
  else {
    np = completedp__;
    while (np->next)
      np = np->next;
    np->next = inFlightp__;
  }
  inFlightp__ = NULL;
#endif
  if (waitp__->ctx_idp == ctx_idp) {
    for (int i = 0; i < waitp__->nr; i++) {
      io_submit(waitp__->ctx_idp[i], 1, waitp__->iocbpp[i]);
    }
    inFlightp2 = waitp__;
    waitp__ = waitp__->next;
  }
  else {
    np = waitp__;
    bool found = false;
    while (np->next) {
      if (np->next->ctx_idp == ctx_idp) { 
        for (int i = 0; i < np->next->nr; i++) {
          io_submit(np->next->ctx_idp[i], 1, np->next->iocbpp[i]);
        }
        inFlightp2 = np->next;
        np->next = np->next->next;
        found = true;
        break;
      }
      np = np->next;
    }
    if (found == false) {
      cerr << "collect called with no waiting request!" << endl;
      exit(1);
    }
  }
#ifndef IO_NOT_AGGRESSIVE
  // collect first the in-flight set of requests
  for (int i = 0; i < inFlightp__->nr; i++) {
    if ((ret = io_getevents(inFlightp__->ctx_idp[inFlightp__->nr_done], 1, 1,
                            inFlightp__->events[inFlightp__->nr_done], NULL)) != 1) {
      cerr << ret << " events returned!" << endl;
      exit(1);
    }
    ++inFlightp__->nr_done;
   }
  inFlightp__->nr = 0;
  // move it to completed
  if (!completedp__) {
    completedp__ = inFlightp__;
  }
  else {
    np = completedp__;
    while (np->next)
      np = np->next;
    np->next = inFlightp__;
  }
  inFlightp__ = NULL;
#endif
  // if our AIO set consists of only 1 request,
  //   submit to disk the head of the waiting list (if not NULL)
  if (inFlightp2->nr == 1 && waitp__)
    submitV_();

  // lastly, collect our AIO request (inFlightp2)
  if ((ret = io_getevents(inFlightp2->ctx_idp[0], 1, 1,
                            inFlightp2->events[0], NULL)) != 1) {
    cerr << ret << " events returned!" << endl;
    exit(1);
  }
 
  if (inFlightp2->nr == 1) {
    delete inFlightp2;
  }
  else {
    inFlightp__ = inFlightp2;
    --inFlightp__->nr;
    ++inFlightp__->nr_done;
    inFlightp__->next = NULL;
  }
  return;
}


// collects a specific AIO request
// (could be completed, in-flight, or in any position at the waiting queue)

void AIOlist_t::collect(io_context_t* ctx_idp) {
  int ret;
  struct AIOlistNode* np;
  struct AIOlistNode* np2;
  struct AIOlistNode* inFlightp2 = NULL;  

  // 1. let's first see if the AIO to be collected is in flight

  if (inFlightp_ && *(inFlightp_->ctx_idp) == *ctx_idp) {
    // our request is in-flight. submit first the head of waiting queue (if not NULL)
    // and then wait until our request is done (timeout is NULL = infinite)
    inFlightp2 = inFlightp_;
    inFlightp_ = NULL;
    if (waitp_)
      submit_();
    if ((ret = io_getevents(*ctx_idp, inFlightp2->nr, inFlightp2->nr,
                            inFlightp2->events, NULL)) != 1) {
      cerr << ret << " events returned!" << endl;
      exit(1);
    }
    delete inFlightp2;
    return;
  }


  // 2. let's see if the AIO is in completed list -- if yes, remove it

  if (completedp_) {
    if (*(completedp_->ctx_idp) == *ctx_idp) {
      np = completedp_;
      completedp_ = completedp_->next; 
      delete np;
      return;
    }
    np = completedp_;
    while(np->next) {
      if (*(np->next->ctx_idp) == *ctx_idp) {
        np2 = np->next;
        np->next = np->next->next;
        delete np2;
        return;
      }
      np = np-> next;
    } 
  }


  // 3. the AIO request is still in waiting queue:
  //    submit our AIO, collect the in flight one, and then ours

  if (!inFlightp_ || !waitp_) {
    cerr << "collect called with no in-flight or waiting request!" << endl;
    exit(1);
  }

  if (*(waitp_->ctx_idp) == *ctx_idp) {
    io_submit(*(waitp_->ctx_idp), waitp_->nr, waitp_->iocbpp);
    inFlightp2 = waitp_;
    waitp_ = waitp_->next;
  }
  else {
    np = waitp_;
    bool found = false;
    while (np->next) {
      if (*(np->next->ctx_idp) == *ctx_idp) {
        io_submit(*(np->next->ctx_idp), np->next->nr, np->next->iocbpp);
        inFlightp2 = np->next;
        np->next = np->next->next;
        found = true;
        break;
      }
      np = np->next;
    }
    if (found == false) {
      cerr << "collect called with no waiting request!" << endl;
      exit(1);
    }
  }

  // collect first the in-flight request
  if ((ret = io_getevents(*(inFlightp_->ctx_idp), inFlightp_->nr, inFlightp_->nr,
                            inFlightp_->events, NULL)) != 1) {
    cerr << ret << " events returned!" << endl;
    exit(1);
  }

  // move it to completed
  if (!completedp_) { 
    completedp_ = inFlightp_;
  }
  else {
    np = completedp_;
    while (np->next)
      np = np->next;
    np->next = inFlightp_;
  }
  inFlightp_ = NULL;

  // then, submit to disk the head of the waiting list (if not NULL)
  if (waitp_)
    submit_();

  // and lastly, collect our AIO request (inFlightp2)
  if ((ret = io_getevents(*(inFlightp2->ctx_idp), inFlightp2->nr, inFlightp2->nr,
                            inFlightp2->events, NULL)) != 1) {
    cerr << ret << " events returned!" << endl;
    exit(1);
  }
  delete inFlightp2;

  return;
}


// check if in-flight request is done (non-blocking)
// if yes, move it to completed, and submit head of waiting list
int AIOlist_t::checkAIO() {
  int ret;
  struct AIOlistNode* np;

  if (!inFlightp_)
    return 0;

  struct timespec timeout;
  timeout.tv_sec = 0;
  timeout.tv_nsec = 0;
  ret = io_getevents(*(inFlightp_->ctx_idp), 1, inFlightp_->nr,
                       inFlightp_->events, &timeout);
  if (ret <= 0)
    return 0;

  inFlightp_->nr_done = inFlightp_->nr_done + ret;
  inFlightp_->nr = inFlightp_->nr - ret;
  if (inFlightp_->nr) {
    return ret;
  }

  // in-flight AIO is done, move it to completed 
  if (!completedp_) {
    completedp_ = inFlightp_;
  }
  else {
    np = completedp_;
    while (np->next)
      np = np->next;
    np->next = inFlightp_;
  }
  inFlightp_ = NULL;

  // submit to disk the head of the waiting list (if not NULL)
  if (waitp_)
    submit_();

  return ret;
}

int AIOlist_t::checkAIOV() {
  int ret;
  struct AIOlistNodeV* np;

  if (!inFlightp__)
    return 0;

  struct timespec timeout;
  timeout.tv_sec = 0;
  timeout.tv_nsec = 0;
  ret = 1;
  int i = 0;
  while (ret > 0) {
    ret = io_getevents(inFlightp__->ctx_idp[inFlightp__->nr_done], 1, 1,
                       inFlightp__->events[inFlightp__->nr_done], &timeout);
    if (ret <= 0)
      return i;
    ++i;
    ++inFlightp__->nr_done;
    --inFlightp__->nr;
    if (!inFlightp__->nr)
      break;
  }

  // in-flight AIO is done, move it to completed
  if (!completedp__) {
    completedp__ = inFlightp__;
  }
  else {
    np = completedp__;
    while (np->next)
      np = np->next;
    np->next = inFlightp__;
  }
  inFlightp__ = NULL;

  // submit to disk the head of the waiting list (if not NULL)
  if (waitp__)
    submitV_();

  return ret;
}

