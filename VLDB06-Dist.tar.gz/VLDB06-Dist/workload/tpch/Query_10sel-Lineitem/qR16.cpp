
// SELECT *
// FROM lineitem
// where L_PARTKEY~10%


class Q : public scan_obj_t {
public:
  Q(int sz = SIZE) : scan_obj_t(sz, sizeof(l_tuple)) {}
  virtual bool predicate(tuple_t* t) {
    l_tuple* tuple = (l_tuple*)t->data;
    if (tuple->L_PARTKEY < 200001)
      return true;
    return false;
  }
  virtual void project(tuple_t* in_tuple, tuple_t* out_tuple) {
    memcpy(out_tuple->data, in_tuple->data, 150);
  }
};


///////////////////////////////////////////////////////////
// Query

void query() {
SIZE = 150;
  executor_t* q = new executor_t(
                          new fscanR("L",
                          new Q()),
                      new NP());
  q->eval();
  delete q;
  return;
}

