// SELECT C1.a ..  C6.a, C12.a, C13.a, C14.a
// from C1 .. C6, C12, C13, C14
// where C2.a 10%

class SFint : public scan_obj_t {
public:
  SFint(int sz = SIZE) : scan_obj_t(sz, 4) { }
  virtual void combine(tuple_t* in_tuple1, tuple_t* in_tuple2, tuple_t* out_tuple) {
    *((int*)out_tuple->data) = *((int*)in_tuple1->data);
    *((int*)(out_tuple->data+4)) = *((int*)in_tuple2->data);
  }
  virtual bool predicate(tuple_t* t) {
    if (*((int*)t->data) < 200001)
      return true;
    return false;
  }
};

class P9 : public print_obj_t {
public:
  virtual void print_tuple(tuple_t* t) {
  cout << *((int*)(t->data+8)) << "|"
       << *((int*)(t->data+4)) << "|"
       << *((int*)(t->data+12)) << "|"
       << *((int*)(t->data+16)) << "|"
       << *((int*)(t->data+20)) << "|"
       << *((int*)(t->data+24)) << "|"
       << *((char*)(t->data+28)) << "|"
       << *((char*)(t->data+29)) << "|"
       << ((char*)(t->data+30)) << endl;
  }
};
       
///////////////////////////////////////////////////////////
// Query

void query() {
  SIZE = 55;
  executor_t* q = new executor_t(
               new fscanC("C14",
                new fscanC("C13",
                 new fscanC("C12",
                  new fscanC("C6",
                   new fscanC("C5",
                    new fscanC("C4",
                     new fscanC("C3",
                      new fscanC("C1",
                       new fscanC("C2",
                        NULL,
                       new SFint()),
                      new Sint(8)),
                     new Sint(12)),
                    new Sint(16)),
                   new Sint(20)),
                  new Sint(24)),
                 new Schar(28)),
                new Schar(29)),
               new Svar(30, 25)),
              new NP());
                  //new P9());
  q->eval();
  delete q;
}
