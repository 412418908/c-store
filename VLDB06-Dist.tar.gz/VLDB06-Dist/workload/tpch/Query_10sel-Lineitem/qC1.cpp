// SELECT C2.a from C2 where C2.a 10%
// C2 is L_PARTKEY. 10% selectivity when < 200001


class SFint : public scan_obj_t {
public:
  SFint(int sz = SIZE) : scan_obj_t(sz, 4) { }
  virtual void combine(tuple_t* in_tuple1, tuple_t* in_tuple2, tuple_t* out_tuple) {
    *((int*)out_tuple->data) = *((int*)in_tuple1->data);
    *((int*)(out_tuple->data+4)) = *((int*)in_tuple2->data);
  }
  virtual bool predicate(tuple_t* t) {
    if (*((int*)t->data) < 200001)
      return true;
    return false;
  }
};


///////////////////////////////////////////////////////////
// Query

void query() {
  SIZE = 8;
  executor_t* q = new executor_t(
                          new fscanC("C2",
                          NULL,
                          new SFint()),
                      new NP());
  q->eval();
  delete q;
}
