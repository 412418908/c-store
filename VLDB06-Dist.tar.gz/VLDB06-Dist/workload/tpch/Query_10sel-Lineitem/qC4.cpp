// SELECT C1.a ..  C4.a from C1 .. C4 where C2.a 10%

class SFint : public scan_obj_t {
public:
  SFint(int sz = SIZE) : scan_obj_t(sz, 4) { }
  virtual void combine(tuple_t* in_tuple1, tuple_t* in_tuple2, tuple_t* out_tuple) {
    *((int*)out_tuple->data) = *((int*)in_tuple1->data);
    *((int*)(out_tuple->data+4)) = *((int*)in_tuple2->data);
  }
  virtual bool predicate(tuple_t* t) {
    if (*((int*)t->data) < 200001)
      return true;
    return false;
  }
};

class P4 : public print_obj_t {
public:
  virtual void print_tuple(tuple_t* t) {
  cout << *((int*)(t->data+8)) << "|"
       << *((int*)(t->data+4)) << "|"
       << *((int*)(t->data+12)) << "|"
       << *((int*)(t->data+16)) << endl;
  }
};
       

///////////////////////////////////////////////////////////
// Query

void query() {
  SIZE = 20;
  executor_t* q = new executor_t(
                   new fscanC("C4",
                    new fscanC("C3",
                     new fscanC("C1",
                      new fscanC("C2",
                       NULL,
                      new SFint()),
                     new Sint(8)),
                    new Sint(12)),
                   new Sint(16)),
                  new NP());
                  //new P4());
  q->eval();
  delete q;
}
