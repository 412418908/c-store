/*
Copyright (c) 2005, Massachusetts Institute of Technology, Brown University, Brandeis University, and University of Massachusetts, Boston. All rights reserved.

Redistribution and use in source and binary forms, with or without modification, are permitted provided that the following conditions are met:

Redistributions of source code must retain the above copyright notice, this list of conditions and the following disclaimer. Redistributions in binary form must reproduce the above copyright notice, this list of conditions and the following disclaimer in the documentation and/or other materials provided with the distribution. Neither the name of the nor the names of its contributors may be used to endorse or promote products derived from this software without specific prior written permission. THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE. 
*/
#ifndef __TPCH_H
#define __TPCH_H

#include "tuple.h"
#include "util.h"
#include "executor.h"
#include <db_cxx.h>
#include <string>
#include <vector>
#include <iostream>
#include <fstream>

//////////////////////////////////////////
// Database tables and workload parameters

// lineitem = 0, orders = 1
enum { LINEITEM, ORDERS };

// moved in tuple.h
//extern char* TPCH_DATA_PATH;

// for CStore:
enum {L_ORDERKEY,    L_PARTKEY,       L_SUPPKEY,  L_LINENUMBER, 
      L_QUANTITY,    L_EXTENDEDPRICE, L_DISCOUNT, L_TAX,
      L_RETURNFLAG,  L_LINESTATUS,    L_SHIPDATE, L_COMMITDATE,
      L_RECEIPTDATE, L_SHIPINSTRUCT,  L_SHIPMODE, L_COMMENT};

enum {O_ORDERKEY,     O_CUSTKEY,     O_TOTALPRICE,   O_ORDERDATE,
      O_SHIPPRIORITY, O_ORDERSTATUS, O_ORDERPRIORITY};

// dictionary entries
extern const char* Instructions[];
extern const char* Modes[];
extern const char* Flags[];
extern const char* Status[];
extern const char* Priorities[]; 

// predefined number of tuples per page
#define L_ARRAY_SIZE 26
#define LC_ARRAY_SIZE 78 
#define LC_BASES_SIZE 4
#define O_ARRAY_SIZE 127
#define OC_ARRAY_SIZE 340
#define OC_BASES_SIZE 4

#define C_PAGE 4088 // 4096 -4 for num_attrs , -4 for bases
extern int C_PAGE_SIZE;

//////////////////////////
// Define tuple structures

// LINEITEM
struct l_tuple {
  int L_ORDERKEY;     // 1
  int L_PARTKEY;      // 2
  int L_SUPPKEY;      // 3
  int L_LINENUMBER;   // 4
  int L_QUANTITY;     // 5
  int L_EXTENDEDPRICE;// 6
  int L_DISCOUNT;     // 7 
  int L_TAX;          // 8
  int L_SHIPDATE;     // 9
  int L_COMMITDATE;   // 10
  int L_RECEIPTDATE;  // 11
    // --> 44 bytes
  char L_RETURNFLAG;  // 12
  char L_LINESTATUS;  // 13
    // ------> + 2 = 46 bytes
  char L_SHIPINSTRUCT[25]; // 14
  char L_SHIPMODE[10];     // 15
  char L_COMMENT[69];      // 16
    // ---------> + 104 = 150 bytes
  char L_padding[2];
    // -----------------------------------> 152 bytes
};

// LINEITEM-Z
struct l_coded_tuple {
  int L_PARTKEY;
  int L_SUPPKEY;
  int L_EXTENDEDPRICE;
    // --> 12 bytes
  unsigned short L_SHIPDATE; // compressed as 2-byte value
  unsigned short L_COMMITDATE; // compressed as 2-byte value
  unsigned short L_RECEIPTDATE; // compressed as 2-byte value
    // ----> + 6 = 18 bytes   
  char L_COMMENT[28]; // = 27 chars + 1byte number of spaces following
    // ------> + 28 = 46 bytes
  char L_coded[4];
    // --------> + 4 = 50 bytes;
  char L_LINESTATUS; // doesn't make sense to compress due to padding
  char L_padding[1];
    // -----------------------------------> 52 bytes
};

//coded
// L_ORDERKEY =   diff, 1 byte (before: 4 bytes)
//--
// L_LINENUMBER = pack, 3 bits         (4 bytes)
// L_SHIPINSTRUCT=dict, 2 bits         (25 bytes)
// L_SHIPMODE =   dict, 3 bits         (10 bytes)
//--
// L_QUANTITY =   pack, 6 bits         (4 bytes)
// L_RETURNFLAG = dict, 2 bits         (1 byte)
//--
// L_DISCOUNT =   dict, 4 bits         (4 bytes)
// L_TAX =        dict, 4 bits         (4 bytes)


// Page structures for LINEITEM and LINEITEM-Z

struct l_tupleArray {
  int num_rows;
  struct l_tuple l_array[L_ARRAY_SIZE];
};

struct l_coded_tupleArray {
  int num_rows;
  struct l_coded_tuple lc_array[LC_ARRAY_SIZE];
  char l_bases[LC_BASES_SIZE];
};

union l_page {
  l_tupleArray lineitemArray;
  char data[4096];
};
      
union l_coded_page {
  l_coded_tupleArray lineitemArrayZ;
  char data[4096];
};


// ORDERS
struct o_tuple {
  int O_ORDERKEY;          // C1
  int O_CUSTKEY;           // C2
  int O_TOTALPRICE;        // C3
  int O_ORDERDATE;         // C4
  int O_SHIPPRIORITY;      // C5
    // --> 20 bytes        
  char O_ORDERSTATUS;      // C6
  char O_ORDERPRIORITY[11];// C7 
    // ------------------->  32 bytes
};

// ORDERS-Z
struct o_coded_tuple {
  int O_CUSTKEY;
  int O_TOTALPRICE;
    // --> 8 bytes
  unsigned int O_coded;
    // ------------------->  12 bytes
};

//coded: 32 bits (unsigned int)
// 
// -- bits 31..20
// O_ORDERKEY     = first diff, then pack, 12 bits (before:  4 bytes)
//
// -- bits 19..6
// O_ORDERDATE    = pack, 14 bits (before: 4 bytes)
//
// -- bits 5..0
// O_ORDERSTATUS =  dict, 2 bits (before:  1 byte )
// O_ORDERPRIORITY= dict, 3 bits         (11 bytes)
// O_SHIPPRIORITY = pack, 1 bit           (4 bytes)


// Page structures for ORDERS and ORDERS-Z

struct o_tupleArray {
  int num_rows;
  struct o_tuple o_array[O_ARRAY_SIZE];
};

struct o_coded_tupleArray {
  int num_rows;
  struct o_coded_tuple oc_array[OC_ARRAY_SIZE];
  char o_bases[OC_BASES_SIZE];
};

union o_page {
  o_tupleArray ordersArray;
  char data[4096];
};

union o_coded_page {
  o_coded_tupleArray ordersArrayZ;
  char data[4096];
};


// ORDERS - CSTORE Coding
//
// O_CUSTKEY    -- same -- 4 bytes         C2
// O_TOTALPRICE -- same -- 4 bytes         C3
// O_ORDERKEY -- delta from prev, uchar 1byte  CZ1
// O_ORDERDATE -- short int, 2 bytes       CZ4
// O_SHIPPRIORITY -- pack 1 bit            CZ5
//   (32 values per 4-byte uint) 
// O_ORDERSTATUS -- dict 2 bits            CZ6
//   (16 values per 4-byte uint)
// O_ORDERPRIORITY -- dict 3 bits           CZ7
//   (10 values per 4-byte uint)
//
// -------------> 11 bytes + 6.2 bits per row


// Page for Cstore
struct cstore_page {
  int num_values;
  char block[C_PAGE];
  char base[4];  
};


////////////////////////////
// Database create/open/close

void create_tpch_rstore(int table, char* name, int compressed);
void create_tpch_cstore(int table, int column, char* name, int compressed);



////////////////////////////////////////////
// Workload/query and other helper functions

void run_tpch();
void run_tpch_cstore();
void tpch_query0();
void tpch_query1();
void tpch_query1z();

void tpch_query5_1();
void tpch_query5_5();

void tpch_query0c();
void tpch_query1c();
void tpch_query1cz();



#endif // __TPCH_H
