// SELECT C4 C1 C2 from O where C4 ~10%

const int TUPLE_SIZE__ = 12;
const int PREDICATE_VALUE__ = 10199; // 10% selectivity

class SFint : public scan_obj_t {
public:
  SFint(int sz = SIZE) : scan_obj_t(sz, 4) { }
  virtual void combine(tuple_t* in_tuple1, tuple_t* in_tuple2, tuple_t* out_tuple) {
    *((int*)out_tuple->data) = *((int*)in_tuple1->data);
    *((int*)(out_tuple->data+4)) = *((int*)in_tuple2->data);
  }
  virtual bool predicate(tuple_t* t) {
    if (*((int*)t->data) > PREDICATE_VALUE__)
      return true;
    return false;
  }
};

class O_PALL__ : public print_obj_t {
public:
  virtual void print_tuple(tuple_t* t) {
    cout << *((int*)(t->data+4)) << " "
         << *((int*)(t->data+8)) << " "
         << *((int*)(t->data+12)) << " " << endl;
  }
};

///////////////////////////////////////////////////////////
// Query

void query() {
  SIZE = TUPLE_SIZE__ + 4;
  executor_t* q = new executor_t(
                   new fscanC("C2",
                    new fscanC("C1",
                     new fscanC("C4",
                      NULL,
                     new SFint()),
                    new Sint(8)),
                   new Sint(12)),
                  new NP());
//                  new O_PALL__());
  q->eval();
  delete q;
}
