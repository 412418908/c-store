
// SELECT O_ORDERDATE, O_ORDERKEY, O_CUSTKEY 
// FROM orders
// where O_ORDERDATE > 10199
// (~10%)

int TUPLE_SIZE__ = 12;
const int PREDICATE_VALUE__ = 10199;

class Q : public scan_obj_t {
public:
  Q(int sz = TUPLE_SIZE__) : scan_obj_t(sz, sizeof(o_tuple)) {}
  virtual bool predicate(tuple_t* t) {
    o_tuple* tuple = (o_tuple*)t->data;
    if (tuple->O_ORDERDATE > PREDICATE_VALUE__)
      return true;
    return false;
  }

  virtual void project(tuple_t* in_tuple, tuple_t* out_tuple) {
    o_tuple* t = (o_tuple*)in_tuple->data;
    //memcpy(out_tuple->data, in_tuple->data, TUPLE_SIZE__);
    *((int*)out_tuple->data) = t->O_ORDERDATE;
    *((int*)(out_tuple->data+4)) = t->O_ORDERKEY;
    *((int*)(out_tuple->data+8)) = t->O_CUSTKEY;
  }
};

class O_P3__ : public print_obj_t {
public:
  virtual void print_tuple(tuple_t* t) {
     cout << *((int*)(t->data)) << " "
         << *((int*)(t->data+4)) << " "
         << *((int*)(t->data+8)) << " " << endl;
  }
};



///////////////////////////////////////////////////////////
// Query

void query() {
  executor_t* q = new executor_t(
                          new fscanR("O",
                          new Q()),
                      new NP());
//                      new O_P3__());
  q->eval();
  delete q;
  return;
}
