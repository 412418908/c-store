// SELECT C4 from O where C4
// O is ORDERS and C4 is O_ORDERDATE

const int TUPLE_SIZE__ = 4;
const int PREDICATE_VALUE__ = 10199; // 10% selectivity

int COUNT__;

class SFint : public scan_obj_t {
public:
  SFint(int sz = SIZE) : scan_obj_t(sz, 4) { }
  virtual void combine(tuple_t* in_tuple1, tuple_t* in_tuple2, tuple_t* out_tuple) {
    *((int*)out_tuple->data) = *((int*)in_tuple1->data);
    *((int*)(out_tuple->data+4)) = *((int*)in_tuple2->data);
  }
  virtual bool predicate(tuple_t* t) {
    if (*((int*)t->data) > PREDICATE_VALUE__)
      return true;
    return false;
  }
};

class O_P1 : public print_obj_t {
public:
  virtual void print_tuple(tuple_t* t) {
//    cout << *((int*)(t->data)) << " " << endl;
    COUNT__++;
  }
};

///////////////////////////////////////////////////////////
// Query


void query() {
  COUNT__ = 0;
  SIZE = TUPLE_SIZE__ + 4;
  executor_t* q = new executor_t(
                          new fscanC("C4",
                          NULL,
                          new SFint()),
                      new NP());
//                      new O_P1());
  q->eval();
//  cout << "Count: " << COUNT__ << endl;
  delete q;
}
