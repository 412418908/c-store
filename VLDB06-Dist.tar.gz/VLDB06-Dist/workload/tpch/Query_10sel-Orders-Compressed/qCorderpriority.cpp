
const int TUPLE_SIZE__ = 11;
//const int PREDICATE_VALUE__ = 10199; // 10% selectivity

int COUNT__;

class SFint : public scan_obj_t {
public:
  SFint(int sz = SIZE) : scan_obj_t(sz, 11) { }
  virtual void combine(tuple_t* in_tuple1, tuple_t* in_tuple2, tuple_t* out_tuple) {
    *((int*)out_tuple->data) = *((int*)in_tuple1->data);
    memcpy(out_tuple->data+4, in_tuple2->data, 11);
  }

  virtual char* get_value_p(char* buf_, int pos) {
    unsigned int uint_container = *((unsigned int*)(buf_ + 4 + 4 * (int)(pos/10)));
   int offset = (pos%10);
    uint_container = 0x7 & (uint_container >> (offset*3));
    // BUG ALERT: we knowingly copy 11 bytes,
    // despite the fact that Priorities[] have between 5-11 bytes
    memcpy(return_value_, Priorities[(int)uint_container], 11);
    return return_value_;
  }

  virtual bool predicate(tuple_t* t) {
   // if (*((int*)t->data) > PREDICATE_VALUE__)
      return true;
   // return false;
  }
private:
  char return_value_[11];
};

class O_P1 : public print_obj_t {
public:
  virtual void print_tuple(tuple_t* t) {
//   cout << (char*)(t->data+4) << " " << endl;
    COUNT__++;
  }
};

///////////////////////////////////////////////////////////
// Query


void query() {
  COUNT__ = 0;
  SIZE = TUPLE_SIZE__ + 4;
  executor_t* q = new executor_t(
                          new fscanC("CZ7",
                          NULL,
                          new SFint()),
//                      new NP());
                    new O_P1());
  q->eval();
  cout << "Count: " << COUNT__ << endl;
  delete q;
}
