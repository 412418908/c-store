// SELECT CZ4, CZ1, C2, CZ6, CZ7 from O where ~ 10% selectivity
// O is ORDERS and CZ4 is O_ORDERDATE compressed to 2 bytes
//                 CZ1 is O_ORDERKEY compressed to 1 byte
                  

const int TUPLE_SIZE__ = 24;
const int PREDICATE_VALUE__ = 10199; // 10% selectivity

int COUNT__;

class SFZsint : public scan_obj_t {
public:
  SFZsint(int sz = SIZE) : scan_obj_t(sz, 2) { }
  virtual void combine(tuple_t* in_tuple1, tuple_t* in_tuple2, tuple_t* out_tuple) {
    *((int*)(out_tuple->data)) = *((int*)in_tuple1->data);
    *((int*)(out_tuple->data+4)) = *((int*)(in_tuple1->data+4));
    *((int*)(out_tuple->data+8)) = *((int*)in_tuple2->data);
  }
  virtual char* get_value_p(char* buf_, int pos) {
    return_value_ =  (int)(*((unsigned short*)(buf_ + 4 + pos*2)));
    return (char*)&return_value_;
  }
  virtual bool predicate(tuple_t* t) {
    if (*((int*)t->data) > PREDICATE_VALUE__)
      return true;
    return false;
  }
private:
 int return_value_;
 int offset_;
};

class SZchar : public Schar {
public:
  SZchar(int offset) : Schar(offset) {}
  virtual char* get_value_p(char* buf_, int pos) {
    unsigned int uint_container = *((unsigned int*)(buf_ + 4 + 4 * (int)(pos/16)));
    int offset = (pos%16);
    uint_container = 0x3 & (uint_container >> (offset*2));
    return_value =  *Status[(int)uint_container];
    return &return_value;
  }
private:
  char return_value;
};

class SZstring : public Svar {
public:
  SZstring(int offset, int attr) : Svar(offset, attr) {}
  virtual char* get_value_p(char* buf_, int pos) {
    unsigned int uint_container = *((unsigned int*)(buf_ + 4 + 4 * (int)(pos/10)));
    int offset = (pos%10);
    uint_container = 0x7 & (uint_container >> (offset*3));
    // BUG ALERT: we knowingly copy 11 bytes
    memcpy(return_value_, Priorities[(int)uint_container], 11);
    return return_value_;
  }
private:
 char return_value_[11];
};


class O_P5 : public print_obj_t {
public:
  virtual void print_tuple(tuple_t* t) {
    cout << *((int*)(t->data+8)) << " "
         << *((int*)(t->data+4)) << " "
         << *((int*)(t->data+12)) << " " 
         << *((char*)(t->data+16)) << " " 
         << (char*)(t->data+17) << " " << endl;
    COUNT__++;
  }
};

///////////////////////////////////////////////////////////
// Query


void query() {
  COUNT__ = 0;
  SIZE = TUPLE_SIZE__ + 4;
  executor_t* q = new executor_t(
                  new fscanC("CZ7",
                    new fscanC("CZ6",
                      new fscanC("C2",
                        new fscanC("CZ4",
                          new fscanC("CZ1",
                          NULL,
                          new SFZintdiffuchar()), 
                        new SFZsint()),
                       new Sint(12)),
                       new SZchar(16)),
                      new SZstring(17, 11)),
                     new NP());
//                  new O_P5());
  q->eval();
  cout << "Count: " << COUNT__ << endl;
  delete q;
}
