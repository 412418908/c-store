// SELECT CZ4 from O where ~ 10% selectivity
// O is ORDERS and CZ4 is O_ORDERDATE compressed to 2 bytes

const int TUPLE_SIZE__ = 4;
const int PREDICATE_VALUE__ = 10199; // 10% selectivity

int COUNT__;

class SFZsint : public scan_obj_t {
public:
  SFZsint(int sz = SIZE) : scan_obj_t(sz, 2) { }
  virtual void combine(tuple_t* in_tuple1, tuple_t* in_tuple2, tuple_t* out_tuple) {
    *((int*)out_tuple->data) = *((int*)in_tuple1->data);
    *((int*)(out_tuple->data+4)) = *((int*)in_tuple2->data);
  }
  virtual char* get_value_p(char* buf_, int pos) {
    return_value_ =  (int)(*((unsigned short*)(buf_ + 4 + pos*2)));
    return (char*)&return_value_;
  }
  virtual bool predicate(tuple_t* t) {
    if (*((int*)t->data) > PREDICATE_VALUE__)
      return true;
    return false;
  }
private:
 int return_value_;
};

class O_P1 : public print_obj_t {
public:
  virtual void print_tuple(tuple_t* t) {
    cout << *((int*)(t->data+4)) << " " << endl;
    COUNT__++;
  }
};

///////////////////////////////////////////////////////////
// Query


void query() {
  COUNT__ = 0;
  SIZE = TUPLE_SIZE__ + 4;
  executor_t* q = new executor_t(
                          new fscanC("CZ4",
                          NULL,
                          new SFZsint()),
                      new NP());
//                      new O_P1());
  q->eval();
//  cout << "Count: " << COUNT__ << endl;
  delete q;
}
