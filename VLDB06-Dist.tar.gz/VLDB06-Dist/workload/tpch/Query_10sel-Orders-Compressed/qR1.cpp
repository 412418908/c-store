
int count;
int TUPLE_SIZE__ = 4;
const int PREDICATE_VALUE__ = 10199;

class Q : public scan_obj_t {
public:
  Q(int sz = TUPLE_SIZE__) : scan_obj_t(sz, sizeof(o_coded_tuple)) {}
  virtual bool predicate(tuple_t* t) {
     if (*((int*)t->data)  > PREDICATE_VALUE__)
      return true;
    return false;
  }

  virtual char* get_value_p(char* buf_, int pos) {
//    tpch_decode_orders_ALL((o_coded_tuple*)(buf_ + 4 + in_tuple_len * pos),
//                           &decoded_tuple_, buf_ + 4084);
    unsigned int uTmp = *((unsigned int*)(buf_ + 4 + in_tuple_len * pos + 8));
    decoded_tuple_ = (int) ((uTmp >> 6) & 0x3FFF);
    return (char*)&decoded_tuple_;
  }

  virtual void project(tuple_t* in_tuple, tuple_t* out_tuple) {
    *((int*)out_tuple->data) = *((int*)in_tuple->data);
  }
private:
  int decoded_tuple_;
};

class O_PALL__ : public print_obj_t {
public:
  virtual void print_tuple(tuple_t* t) {
/*    o_tuple* pt = (o_tuple*)t->data;
    cout << pt->O_ORDERKEY << " "
         << pt->O_CUSTKEY << " "
         << pt->O_TOTALPRICE << " "
         << pt->O_ORDERDATE << " "
         << pt->O_SHIPPRIORITY << " "
         << pt->O_ORDERSTATUS << " " 
         << pt->O_ORDERPRIORITY << " " << endl;
*/
   count++;
  }
};



///////////////////////////////////////////////////////////
// Query

void query() {
  count = 0;
  executor_t* q = new executor_t(
                          new fscanR("O-Z",
                          new Q()),
                      new NP());
//                      new O_PALL__());
  q->eval();
  cout << "Count: " << count << endl;
  delete q;
  return;
}
