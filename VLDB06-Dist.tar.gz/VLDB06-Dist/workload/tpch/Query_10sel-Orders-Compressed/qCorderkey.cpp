const int TUPLE_SIZE__ = 4;

int COUNT__;

class SFZdiffuchar : public scan_obj_t {
public:
  SFZdiffuchar(int sz = SIZE) : scan_obj_t(sz, 1) { }
  virtual void combine(tuple_t* in_tuple1, tuple_t* in_tuple2, tuple_t* out_tuple) {
    *((int*)out_tuple->data) = *((int*)in_tuple1->data);
    *((int*)(out_tuple->data+4)) = *((int*)in_tuple2->data);
  }
virtual char* get_value_p(char* buf_, int pos) {
    if (pos == 0) // update base
      return_value_ = *((int*)(buf_ + 4092));
    else
      return_value_ =  return_value_ + (int)(*((unsigned char*)(buf_ + 4 + pos*1)));
    return (char*)&return_value_;
  }

  virtual bool predicate(tuple_t* t) {
//    if (*((int*)t->data) > PREDICATE_VALUE__)
      return true;
  //  return false;
  }
private:
 int return_value_;
};

class O_P1 : public print_obj_t {
public:
  virtual void print_tuple(tuple_t* t) {
    cout << *((int*)(t->data+4)) << " " << endl;
    COUNT__++;
  }
};

///////////////////////////////////////////////////////////
// Query


void query() {
  COUNT__ = 0;
  SIZE = TUPLE_SIZE__ + 4;
  executor_t* q = new executor_t(
                          new fscanC("CZ1",
                          NULL,
                          new SFZdiffuchar()),
//                      new NP());
                      new O_P1());
  q->eval();
  cout << "Count: " << COUNT__ << endl;
  delete q;
}
