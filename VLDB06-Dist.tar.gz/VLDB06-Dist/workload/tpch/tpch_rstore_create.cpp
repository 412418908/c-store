/*
Copyright (c) 2005, Massachusetts Institute of Technology, Brown University, Brandeis University, and University of Massachusetts, Boston. All rights reserved.

Redistribution and use in source and binary forms, with or without modification, are permitted provided that the following conditions are met:

Redistributions of source code must retain the above copyright notice, this list of conditions and the following disclaimer. Redistributions in binary form must reproduce the above copyright notice, this list of conditions and the following disclaimer in the documentation and/or other materials provided with the distribution. Neither the name of the nor the names of its contributors may be used to endorse or promote products derived from this software without specific prior written permission. THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE. 
*/
#include <stdlib.h>
#include <stddef.h>
#include <stdio.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include "tpch.h"

using namespace std;

void load_table_TPCH_rstore(int tableNumber, int compressed);
int fd;

/////////////////////////////
// Database create/open/close

void create_tpch_rstore(int table, char* name, int compressed) 
{
  fd = open(name, (O_CREAT|O_RDWR|O_LARGEFILE), 0644);
  if (fd < 0) {
    cerr << "error!" << endl;
    exit(1);
  }
  cerr << "loading " << name << ".." << " page size = " << sizeof(l_page) << endl;
  load_table_TPCH_rstore(table, compressed);
  cerr << "finished!" << endl;
  close (fd);
}

void load_table_TPCH_rstore(int tableNumber, int compressed)
{

  string inputFileName;
  unsigned int numOfColumns;
  string keyIndex;
  int page_size;

  l_tuple lineitem;
  l_coded_tuple lineitemZ;
  l_page lineitemPage;
  l_coded_page lineitemPageZ;
  int base_L_ORDERKEY = 0;

  o_tuple orders;
  o_coded_tuple ordersZ;
  o_page ordersPage;
  o_coded_page ordersPageZ;
  int base_O_ORDERKEY = 0;

  unsigned int uTmp, uTmp1, uTmp2, uTmp3;
  unsigned int counter = 0;
  int page_index = 0;
  int row_index = 0;

  string dataPath = TPCH_DATA_PATH;
  switch (tableNumber) {
    case LINEITEM:
      inputFileName = "/data/rstore/tpch/scale10/lineitem.tbl.full";
      numOfColumns = 16;
      if (!compressed)
        page_size = L_ARRAY_SIZE;
      else
        page_size = LC_ARRAY_SIZE;
      break;		
    case ORDERS:
      inputFileName =   "/data/rstore/tpch/scale40/orders.tbl.full";
      numOfColumns = 9;
      if (!compressed)
        page_size = O_ARRAY_SIZE;
      else
        page_size = OC_ARRAY_SIZE;
      break;
    default:
      cerr << "not sure what table you want to load, exiting..." << endl;
      exit(1);
  }

  fstream inFile;
  vector<string> tokens;
  vector<string>::iterator itr;
  inFile.open( inputFileName.c_str(), ios::in );

  if (!inFile.is_open()) { 
    cout << inputFileName << " not found! " << endl;
    exit(1);
  }
  for (unsigned i=0; i<numOfColumns; ++i) tokens.push_back("");
  cerr << "\tLoading " << inputFileName << "..." << endl;
  char str[512];
  int str_sz=sizeof(str);

  while ( !inFile.eof() ) {
    inFile.getline(str, str_sz);
    string s(str);
    if (s.length()) {
      if (tableNumber == LINEITEM)  {
        Tokenize(s, tokens, "|");
 
        // first read into a regular lineitem tuple

        lineitem.L_ORDERKEY = atoi(tokens[0].c_str());
        lineitem.L_PARTKEY = atoi(tokens[1].c_str());
        lineitem.L_SUPPKEY = atoi(tokens[2].c_str());
        lineitem.L_LINENUMBER = atoi(tokens[3].c_str());
        lineitem.L_QUANTITY = atoi(tokens[4].c_str());
        lineitem.L_EXTENDEDPRICE = atoi(tokens[5].c_str());
        lineitem.L_DISCOUNT = (int)(atof(tokens[6].c_str()) * 100.0 + 0.1);
        lineitem.L_TAX = (int)(atof(tokens[7].c_str()) * 100.0 + 0.1);
        lineitem.L_RETURNFLAG = *(tokens[8].c_str());
        lineitem.L_LINESTATUS = *(tokens[9].c_str());
        lineitem.L_SHIPDATE = dateToDays(tokens[10].c_str());
        lineitem.L_COMMITDATE = dateToDays(tokens[11].c_str());
        lineitem.L_RECEIPTDATE = dateToDays(tokens[12].c_str());
        memcpy(lineitem.L_SHIPINSTRUCT, tokens[13].c_str(), tokens[13].size()+1);
        memcpy(lineitem.L_SHIPMODE, (void*)tokens[14].c_str(), tokens[14].size()+1);
        //memcpy(lineitem.L_COMMENT, (void*)tokens[15].c_str(), tokens[15].size()+1);
        memcpy(lineitem.L_COMMENT, (void*)tokens[15].c_str(), 27);
        lineitem.L_COMMENT[26] = '\0';

        // now pack into a compressed lineitem tuple
        if (compressed) {
          lineitemZ.L_PARTKEY = lineitem.L_PARTKEY; 
          lineitemZ.L_SUPPKEY = lineitem.L_SUPPKEY;
          lineitemZ.L_EXTENDEDPRICE = lineitem.L_EXTENDEDPRICE;
          memcpy(lineitemZ.L_COMMENT, lineitem.L_COMMENT, 27);
          lineitemZ.L_LINESTATUS = lineitem.L_LINESTATUS;

          // compressed as 2-byte values
          lineitemZ.L_SHIPDATE = (unsigned short)lineitem.L_SHIPDATE;
          lineitemZ.L_COMMITDATE = (unsigned short)lineitem.L_COMMITDATE;
          lineitemZ.L_RECEIPTDATE = (unsigned short)lineitem.L_RECEIPTDATE;

          //make sure you set init value for orderkey
          // L_ORDERKEY =   diff, 1 byte (before: 4 bytes)

          lineitemZ.L_coded[0] = (char)(lineitem.L_ORDERKEY - base_L_ORDERKEY);

          // L_LINENUMBER = pack, 3 bits         (4 bytes)
          // L_SHIPMODE =   dict, 3 bits         (10 bytes)
          // L_SHIPINSTRUCT=dict, 2 bits         (25 bytes)
          uTmp = (unsigned int)lineitem.L_LINENUMBER;
          uTmp1 = uTmp << 5;
       
          for (int i = 0; i < 7; i++)
          //TODO correct sizeof with actual number of bytes
          // also exit if problem in data
            if (!memcmp(Modes[i], lineitem.L_SHIPMODE, sizeof (Modes[i]))){
              uTmp = (unsigned int) i;
              break;
            }
          uTmp2 = uTmp << 2;

          for (int i = 0; i < 4; i++)
          //TODO correct sizeof with actual number of bytes
          // also exit if problem in data
            if (!memcmp(Instructions[i], lineitem.L_SHIPINSTRUCT, sizeof (Instructions[i]))) {
              uTmp3 = (unsigned int) i;
              break;
            }
          
          uTmp = uTmp1 | uTmp2 | uTmp3;
          lineitemZ.L_coded[1] = (char)uTmp;

          // L_QUANTITY =   pack, 6 bits         (4 bytes)
          // L_RETURNFLAG = dict, 2 bits         (1 byte)
          uTmp = (unsigned int)lineitem.L_QUANTITY;
          uTmp1 = uTmp << 2;
          for (int i = 0; i < 3; i++)
            if (*Flags[i] == lineitem.L_RETURNFLAG) {
              uTmp2 = (unsigned int) i;
              break;
            }
          uTmp = uTmp1 | uTmp2;
          lineitemZ.L_coded[2] = (char)uTmp;

          // L_DISCOUNT =   dict, 4 bits         (4 bytes)
          // L_TAX =        dict, 4 bits         (4 bytes)
          uTmp = (unsigned int) lineitem.L_DISCOUNT;
          uTmp1 = uTmp << 4;
          uTmp2 = (unsigned int) lineitem.L_TAX;
          uTmp = uTmp1 | uTmp2;
          lineitemZ.L_coded[3] = (char)uTmp;

        } // if compressed


        if (!compressed) { 
          memcpy(&lineitemPage.lineitemArray.l_array[row_index], &lineitem, sizeof(l_tuple));
        }
        else {
          memcpy(&lineitemPageZ.lineitemArrayZ.lc_array[row_index], &lineitemZ, sizeof(l_coded_tuple));
        }
        row_index++;
        if (row_index != page_size) {
          ++counter;
          if ((counter % 100000) == 0)
            cerr << "count:" << counter << endl;
          continue;
        }
        if (!compressed) {
          lineitemPage.lineitemArray.num_rows = row_index;
        }
        else {
          lineitemPageZ.lineitemArrayZ.num_rows = row_index;
          // BASES
          *(int*)(lineitemPageZ.lineitemArrayZ.l_bases) = base_L_ORDERKEY;
          base_L_ORDERKEY = lineitem.L_ORDERKEY;
        }

        size_t byte_count = 0;
        if (!compressed) {
          byte_count = write(fd, &lineitemPage, sizeof(l_page));
          if (byte_count != sizeof(l_page)) {
            cerr << "byte written: " << byte_count << " but it should be " << sizeof(l_page) << endl;
            cerr << "at row # " << counter+1  << endl;
          }
          assert(byte_count==sizeof(l_page));
        } else {
          byte_count = write(fd, &lineitemPageZ, sizeof(l_coded_page));
          if (byte_count != sizeof(l_coded_page)) {
            cerr << "byte written: " << byte_count << " but it should be " << sizeof(l_coded_page) << endl;
            cerr << "at row # " << counter+1  << endl;
          }
          assert(byte_count==sizeof(l_page));
        }
        page_index++;
        row_index = 0;
        ++counter;
        if ( (counter%100000) == 0 ) {
          cerr << "counter:" << counter << endl;
        }
      }	
      else if (tableNumber == ORDERS)  {

        Tokenize(s, tokens, "|");
        orders.O_ORDERKEY = atoi(tokens[0].c_str());
        orders.O_CUSTKEY = atoi(tokens[1].c_str());
        orders.O_TOTALPRICE = (int)(atof(tokens[3].c_str()) * 100.0 + 0.1);
        orders.O_ORDERDATE = dateToDays(tokens[4].c_str());
        orders.O_SHIPPRIORITY = atoi(tokens[7].c_str());
        orders.O_ORDERSTATUS = *(tokens[2].c_str());
        memcpy(orders.O_ORDERPRIORITY, (void*)tokens[5].c_str(), 11);
        orders.O_ORDERPRIORITY[10] = '\0';

        if (compressed) {
          ordersZ.O_CUSTKEY = orders.O_CUSTKEY;
          ordersZ.O_TOTALPRICE = orders.O_TOTALPRICE;

          // O_ORDERKEY =   diff, then pack into 12 bits (before: 4 bytes)
          uTmp = (unsigned int)(orders.O_ORDERKEY - base_O_ORDERKEY);
          uTmp1 = uTmp << 20;

          // O_ORDERDATE = pack, 14 bits (before: 4 bytes)
          uTmp = (unsigned int)orders.O_ORDERDATE;
          uTmp2 = uTmp << 6;

          // O_ORDERSTATUS =  dict, 2 bits (before:  1 byte )
          // O_ORDERPRIORITY= dict, 3 bits         (11 bytes)
          // O_SHIPPRIORITY = pack, 1 bit           (4 bytes)

          bool found = false;
          for (int i = 0; i < 3; i++) {
            if (*Status[i] == orders.O_ORDERSTATUS) {
              uTmp = (unsigned int) i;
              found = true;
              break;
            }
          }
          if (found == false) {
            cerr << "Error in data! exiting " << endl;
            exit(1);
          }
          uTmp3 = uTmp << 4;

          found = false;
          for (int i = 0; i < 5; i++) {
            // comparing first 3 bytes is enough
            if (!memcmp(Priorities[i], orders.O_ORDERPRIORITY, 3)) {
              uTmp = (unsigned int) i;
              found = true;
              break;
            }
          }
          if (found == false) {
            cerr << "Error in data! exiting " << endl;
            exit(1);
          }
          uTmp3 = uTmp3 | (uTmp << 1);

          uTmp = (unsigned int)orders.O_SHIPPRIORITY;
          uTmp = 0x1 & uTmp;
          uTmp3 = uTmp3 | uTmp;

          // Final composition of o_coded
          uTmp = uTmp1 | uTmp2 | uTmp3;
          ordersZ.O_coded = uTmp;
        } // compression

        if (!compressed) { 
          memcpy(&ordersPage.ordersArray.o_array[row_index], &orders, sizeof(o_tuple));
        }
        else {
          memcpy(&ordersPageZ.ordersArrayZ.oc_array[row_index], &ordersZ, sizeof(o_coded_tuple));
        }

        row_index++;
        if (row_index != page_size) {
          ++counter;
          if ((counter % 100000) == 0)
            cerr << "count:" << counter << endl;
          continue;
        }

        if (!compressed) {
          ordersPage.ordersArray.num_rows = row_index;
        }
        else {
          ordersPageZ.ordersArrayZ.num_rows = row_index;
          // BASES
          *(int*)(ordersPageZ.ordersArrayZ.o_bases) = base_O_ORDERKEY;
          base_O_ORDERKEY = orders.O_ORDERKEY;
        }

        size_t byte_count = 0;

        if (!compressed) {
          byte_count = write(fd, &ordersPage, sizeof(o_page));
          if (byte_count != sizeof(o_page)) {
            cerr << "byte written: " << byte_count << " but it should be " << sizeof(o_page) << endl;
            cerr << "at row # " << counter+1  << endl;
          }
          assert(byte_count==sizeof(o_page));
        } else {
          byte_count = write(fd, &ordersPageZ, sizeof(o_coded_page));
          if (byte_count != sizeof(o_coded_page)) {
            cerr << "byte written: " << byte_count << " but it should be " << sizeof(o_coded_page) << endl;
            cerr << "at row # " << counter+1  << endl;
          }
          assert(byte_count==sizeof(o_coded_page));
        }
        page_index++;
        row_index = 0;
        ++counter;
    }
    else 
        break;
    }
  }

  size_t byte_count = 0;
  // tails..
  if (row_index) {
    if (tableNumber == LINEITEM) {
      if (!compressed) {
        lineitemPage.lineitemArray.num_rows = row_index;
        byte_count = write(fd, &lineitemPage, sizeof(l_page));
        assert(byte_count==sizeof(l_page));
      }
      else {
        lineitemPageZ.lineitemArrayZ.num_rows = row_index;
        // BASES
        *(int*)(lineitemPageZ.lineitemArrayZ.l_bases) = base_L_ORDERKEY;
        byte_count = write(fd, &lineitemPageZ, sizeof(l_coded_page));
        assert(byte_count==sizeof(l_coded_page));
      }
    }
    else {
    //ORDERS
      if (!compressed) {
        ordersPage.ordersArray.num_rows = row_index;
        byte_count = write(fd, &ordersPage, sizeof(o_page));
        assert(byte_count==sizeof(o_page));
      }
      else {
        ordersPageZ.ordersArrayZ.num_rows = row_index;
        // BASES
        *(int*)(ordersPageZ.ordersArrayZ.o_bases) = base_O_ORDERKEY;
        byte_count = write(fd, &ordersPageZ, sizeof(o_coded_page));
        assert(byte_count==sizeof(o_coded_page));
      }
    }
  }

  //terminating page
  if (tableNumber == LINEITEM) {
    if (!compressed) {
      memset(&lineitemPage, 0, sizeof(l_page));
      byte_count = write(fd, &lineitemPage, sizeof(l_page));
      assert(byte_count==sizeof(l_page));
    } else {
      memset(&lineitemPageZ, 0, sizeof(l_coded_page));
      byte_count = write(fd, &lineitemPageZ, sizeof(l_coded_page));
      assert(byte_count==sizeof(l_coded_page));
    }
  } else if (tableNumber == ORDERS) {
    if (!compressed) {
      memset(&ordersPage, 0, sizeof(o_page));
      byte_count = write(fd, &ordersPage, sizeof(o_page));
      assert(byte_count==sizeof(o_page));
    } else {
      memset(&ordersPageZ, 0, sizeof(o_coded_page));
      byte_count = write(fd, &ordersPageZ, sizeof(o_coded_page));
      assert(byte_count==sizeof(o_coded_page));
    }
  }

  cerr << "\tFinished loading" << inputFileName <<"..." << endl;
  cerr << "\t loaded: " << page_index <<" pages / " << counter << " rows"<< endl;
  inFile.close();
}
