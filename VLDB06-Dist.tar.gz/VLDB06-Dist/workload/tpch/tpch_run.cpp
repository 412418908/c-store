/*
Copyright (c) 2005, Massachusetts Institute of Technology, Brown University, Brandeis University, and University of Massachusetts, Boston. All rights reserved.

Redistribution and use in source and binary forms, with or without modification, are permitted provided that the following conditions are met:

Redistributions of source code must retain the above copyright notice, this list of conditions and the following disclaimer. Redistributions in binary form must reproduce the above copyright notice, this list of conditions and the following disclaimer in the documentation and/or other materials provided with the distribution. Neither the name of the nor the names of its contributors may be used to endorse or promote products derived from this software without specific prior written permission. THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE. 
*/
#include "tpch.h"

using std::cerr;
using std::cout;
using std::endl;

// TODO for future release:
// unify tpch_cstore_create and tpch_rstore_create in one file
// and move the following there
const char* Instructions[] =
  {"DELIVER IN PERSON", "COLLECT COD", "NONE", "TAKE BACK RETURN"};
const char* Modes[] =
  {"REG AIR", "AIR", "RAIL", "SHIP", "TRUCK", "MAIL", "FOB"};
const char* Flags[] = {"A", "N", "R"};
const char* Status[] = {"F", "O", "P"};
const char* Priorities[] = {"1-URGENT", "2-HIGH", "3-MEDIUM", "4-NOT SPEC", "5-LOW"};

///////////////////////////////////////////////////////////
// Generic print objects

class NP : public print_obj_t {
public:
  virtual void print_tuple(tuple_t* t) { }
};

class L_ALL : public print_obj_t {
public:
  virtual void print_tuple(tuple_t* t) {
    l_tuple* ltp = (l_tuple*)t->data;
    cout << ltp->L_ORDERKEY << "|"
         << ltp->L_PARTKEY << "|"
         << ltp->L_SUPPKEY << "|"
         << ltp->L_LINENUMBER << "|"
         << ltp->L_QUANTITY << "|"
         << ltp->L_EXTENDEDPRICE << "|"
         << ltp->L_DISCOUNT << "|"
         << ltp->L_TAX << "|"
         << ltp->L_RETURNFLAG << "|"
         << ltp->L_LINESTATUS << "|"
         << ltp->L_SHIPDATE << "|"
         << ltp->L_COMMITDATE << "|"
         << ltp->L_RECEIPTDATE << "|"
         << ltp->L_SHIPINSTRUCT << "|"
         << ltp->L_SHIPMODE << "|"
         << ltp->L_COMMENT << "|" << endl;
  }
};

class O_ALL : public print_obj_t {
public:
  virtual void print_tuple(tuple_t* t) {
    o_tuple* pt = (o_tuple*)t->data;
    cout << pt->O_ORDERKEY << "|"
         << pt->O_CUSTKEY << "|"
         << pt->O_TOTALPRICE << "|"
         << pt->O_ORDERDATE << "|"
         << pt->O_SHIPPRIORITY << "|"
         << pt->O_ORDERSTATUS << "|"
         << pt->O_ORDERPRIORITY << "|" << endl;
  }
};

///////////////////////////////////////////////////////////
// Decoders

void tpch_decode_lineitem_ALL(tuple_t* in_tuple, tuple_t* out_tuple, char* bases) {

  // L_PARTKEY | L_SUPPKEY | L_EXTENDEDPRICE | L_COMMENT | 
  ((l_tuple*)out_tuple->data)->L_PARTKEY = ((l_coded_tuple*)in_tuple->data)->L_PARTKEY;
  ((l_tuple*)out_tuple->data)->L_SUPPKEY = ((l_coded_tuple*)in_tuple->data)->L_SUPPKEY;
  ((l_tuple*)out_tuple->data)->L_EXTENDEDPRICE = ((l_coded_tuple*)in_tuple->data)->L_EXTENDEDPRICE;
  memcpy(((l_tuple*)out_tuple->data)->L_COMMENT, ((l_coded_tuple*)in_tuple->data)->L_COMMENT, 27);
  ((l_tuple*)out_tuple->data)->L_LINESTATUS = ((l_coded_tuple*)in_tuple->data)->L_LINESTATUS;

  // L_SHIPDATE | L_COMMITDATE | L_RECEIPTDATE
  ((l_tuple*)out_tuple->data)->L_SHIPDATE = (int)(((l_coded_tuple*)in_tuple->data)->L_SHIPDATE);
  ((l_tuple*)out_tuple->data)->L_COMMITDATE = (int)(((l_coded_tuple*)in_tuple->data)->L_COMMITDATE);
  ((l_tuple*)out_tuple->data)->L_RECEIPTDATE = (int)(((l_coded_tuple*)in_tuple->data)->L_RECEIPTDATE);

  // (with bases) L_ORDERKEY
  ((l_tuple*)out_tuple->data)->L_ORDERKEY = (int)(((l_coded_tuple*)in_tuple->data)->L_coded[0])
                                          + *((int*)bases);

  unsigned int uTmp, uTmp1, uTmp2, uTmp3;

  // L_LINENUMBER | L_SHIPMODE | L_SHIPINSTRUCT
  uTmp = (unsigned int)((unsigned char)(((l_coded_tuple*)in_tuple->data)->L_coded[1]));
  uTmp1 = uTmp >> 5; 
  ((l_tuple*)out_tuple->data)->L_LINENUMBER = (int)uTmp1;
  uTmp2 = (uTmp >> 2) & 0x7;
  memcpy(((l_tuple*)out_tuple->data)->L_SHIPMODE,
         Modes[(int)uTmp2], 10); 
  uTmp3 = uTmp & 0x3;
  memcpy(((l_tuple*)out_tuple->data)->L_SHIPINSTRUCT,
        Instructions[(int)uTmp3], 25);

  // L_QUANTITY | L_RETURNFLAG
  uTmp = (unsigned int)((unsigned char)(((l_coded_tuple*)in_tuple->data)->L_coded[2]));
  uTmp1 = uTmp >> 2;
  ((l_tuple*)out_tuple->data)->L_QUANTITY = (int)uTmp1;
  uTmp2 = uTmp & 0x3;
  ((l_tuple*)out_tuple->data)->L_RETURNFLAG = *Flags[(int)uTmp2];

  // L_DISCOUNT | L_TAX
  uTmp = (unsigned int)((unsigned char)(((l_coded_tuple*)in_tuple->data)->L_coded[3]));
  uTmp1 = uTmp >> 4;
  ((l_tuple*)out_tuple->data)->L_DISCOUNT = (float)uTmp1;
  uTmp2 = uTmp & 0xF;
  ((l_tuple*)out_tuple->data)->L_TAX = (float)uTmp2;
  
}

void tpch_decode_orders_ALL(o_coded_tuple* in_tuple, o_tuple* out_tuple, char* bases) {

  // O_CUSTKEY | O_TOTALPRICE
  out_tuple->O_CUSTKEY = in_tuple->O_CUSTKEY;
  out_tuple->O_TOTALPRICE = in_tuple->O_TOTALPRICE;

  unsigned int uTmp, uTmp1, uTmp2, uTmp3;
  uTmp = in_tuple->O_coded; 

  // O_ORDERKEY
  uTmp1 = uTmp >> 20;
  out_tuple->O_ORDERKEY = (int)uTmp1 + *((int*)bases);

  // O_ORDERDATE
  uTmp1 = (uTmp >> 6) & 0x3FFF;
  out_tuple->O_ORDERDATE = (int)uTmp1;

  // O_ORDERSTATUS
  uTmp1 = (uTmp >> 4) & 0x3;
  out_tuple->O_ORDERSTATUS = *Status[(int)uTmp1];
  // O_ORDERPRIORITY
  uTmp2 = (uTmp >> 1) & 0x7;
  memcpy(out_tuple->O_ORDERPRIORITY, Priorities[(int)uTmp2], 11);
  // O_SHIPPRIORITY
  uTmp3 = uTmp & 0x1;
  out_tuple->O_SHIPPRIORITY = (int)uTmp3;

}


///////////////////////////////////////////////////////////
// Generic scan objects

// each query should override this with the 
// total size of the projected tuple (+ 4 bytes for position)
int SIZE = 4;

class Sint : public scan_obj_t {
public:
  Sint(int offset, int attr = 4, int sz = SIZE)
      : scan_obj_t(sz, attr, true) {attr_ = attr; offset_ = offset; }
  virtual void combine(tuple_t* in_tuple1, tuple_t* in_tuple2, tuple_t* out_tuple) {
    *((int*)(out_tuple->data+offset_)) = *((int*)in_tuple2->data);
   }
private:
 int attr_;
 int offset_;
};

class Schar : public scan_obj_t {
public:
  Schar(int offset, int attr = 1, int sz = SIZE)
      : scan_obj_t(sz, attr, true) {attr_ = attr; offset_ = offset; }
  virtual void combine(tuple_t* in_tuple1, tuple_t* in_tuple2, tuple_t* out_tuple) {
    *((char*)(out_tuple->data+offset_)) = *((char*)in_tuple2->data);
  }
private:
 int attr_;
 int offset_;
};

class Svar : public scan_obj_t {
public:
  Svar(int offset, int attr, int sz = SIZE)
      : scan_obj_t(sz, attr, true) {attr_ = attr; offset_ = offset; }
  virtual void combine(tuple_t* in_tuple1, tuple_t* in_tuple2, tuple_t* out_tuple) {
    memcpy(out_tuple->data+offset_, in_tuple2->data, attr_); 
  }
private: 
 int attr_;
 int offset_;
};

// Important: the following type MUST see all attributes to function correctly
//   here we assume that this is always the first scanner (o.w., modify "combine")
class SFZintdiffuchar : public scan_obj_t {
public:
  SFZintdiffuchar(int offset = 4, int attr = 1, int sz = 8)
      : scan_obj_t(sz, attr) {attr_ = attr; offset_ = offset;  }
  virtual void combine(tuple_t* in_tuple1, tuple_t* in_tuple2, tuple_t* out_tuple) {
    *((int*)out_tuple->data) = *((int*)in_tuple1->data);
    *((int*)(out_tuple->data+offset_)) = *((int*)in_tuple2->data);
  }
  virtual char* get_value_p(char* buf_, int pos) {
    if (pos == 0) // update base
      return_value_ = *((int*)(buf_ + 4092));
    else
      return_value_ =  return_value_ + (int)(*((unsigned char*)(buf_ + 4 + pos*1)));
    return (char*)&return_value_;
  }
private:
 int return_value_;
 int attr_;
 int offset_;
};

class SZintdiff  : public scan_obj_t {
public:
  SZintdiff (int offset, int sz = SIZE)
      : scan_obj_t(sz, 2, true) {offset_ = offset; }
  virtual void combine(tuple_t* in_tuple1, tuple_t* in_tuple2, tuple_t* out_tuple) {
    *((int*)(out_tuple->data+offset_)) = *((int*)in_tuple2->data);
  }
  virtual char* get_value_p(char* buf_, int pos) {
    return_value_ =  (int)(*((unsigned short*)(buf_ + 4 + pos*2)))
                     + *((int*)(buf_ + 4092)) ;
    return (char*)&return_value_;
  }
private:
 int offset_;
 int return_value_;
};


#include "tpch_query.cpp"
