
// SELECT O_ORDERDATE 
// FROM orders
// where O_ORDERDATE > 10199
// (~10%)

int TUPLE_SIZE__ = 4;
const int PREDICATE_VALUE__ = 10199;

class Q : public scan_obj_t {
public:
  Q(int sz = TUPLE_SIZE__) : scan_obj_t(sz, sizeof(o_tuple)) {}
  virtual bool predicate(tuple_t* t) {
    o_tuple* tuple = (o_tuple*)t->data;
    if (tuple->O_ORDERDATE > PREDICATE_VALUE__)
      return true;
    return false;
  }

  virtual void project(tuple_t* in_tuple, tuple_t* out_tuple) {
    o_tuple* t = (o_tuple*)in_tuple->data;
    //memcpy(out_tuple->data, in_tuple->data, TUPLE_SIZE__);
    *((int*)out_tuple->data) = t->O_ORDERDATE;
  }
};

class O_PALL__ : public print_obj_t {
public:
  virtual void print_tuple(tuple_t* t) {
    o_tuple* pt = (o_tuple*)t->data;
    cout << pt->O_ORDERKEY << " "
         << pt->O_CUSTKEY << " "
         << pt->O_TOTALPRICE << " "
         << pt->O_ORDERDATE << " "
         << pt->O_SHIPPRIORITY << " "
         << pt->O_ORDERSTATUS << " " << endl;
//         << pt->O_ORDERPRIORITY << " " << endl;
  }
};



///////////////////////////////////////////////////////////
// Query

void query() {
  executor_t* q = new executor_t(
                          new fscanR("O",
                          new Q()),
                      new NP());
//                      new O_PALL__());
  q->eval();
  delete q;
  return;
}
