/*
Copyright (c) 2005, Massachusetts Institute of Technology, Brown University, Brandeis University, and University of Massachusetts, Boston. All rights reserved.

Redistribution and use in source and binary forms, with or without modification, are permitted provided that the following conditions are met:

Redistributions of source code must retain the above copyright notice, this list of conditions and the following disclaimer. Redistributions in binary form must reproduce the above copyright notice, this list of conditions and the following disclaimer in the documentation and/or other materials provided with the distribution. Neither the name of the nor the names of its contributors may be used to endorse or promote products derived from this software without specific prior written permission. THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE. 
*/
#include <stdlib.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>

#include "tpch.h"


using namespace std;

void load_table_TPCH_cstore(int tableNumber, int columnNumber, int compressed);

// Declare workload parameters here

int C_PAGE_SIZE = C_PAGE; // init to uncompressed char type
int cstore_fd;

/////////////////////////////
// Database create/open/close

void create_tpch_cstore(int table, int column, char* name, int compressed) {

  cstore_fd = open(name, (O_CREAT|O_WRONLY|O_LARGEFILE), 0644);
  if (cstore_fd < 0) {
    cerr << "error!" << endl;
    exit(1);
  }
  
  cerr << "loading " << name << ".." << endl;

  load_table_TPCH_cstore(table, column, compressed);
  
  cerr << "finished!" << endl;
  close (cstore_fd);
}

void load_table_TPCH_cstore(int tableNumber, int columnNumber, int compressed)
{
  string inputFileName;
  unsigned int numOfColumns;
  string keyIndex;
  int page_size;

  l_tuple lineitem;
  o_tuple orders;
  int base_L_ORDERKEY = 0;
  int base_O_ORDERKEY = 0;
  int delta_prev_value = 0;
  int container_index = 0;
  unsigned int uint_container = 0;
  int c_value_multiplier = 0;
  unsigned int uTmp = 0;
  bool found = false;

  unsigned int counter = 0;
  int page_index = 0;
  int row_index = 0;

  int c_width = sizeof(int); // init to integer
  cstore_page l_cstore_page;
  cstore_page o_cstore_page;
  memset(&l_cstore_page, 0, sizeof(cstore_page)); 
  memset(&o_cstore_page, 0, sizeof(cstore_page)); 

  string dataPath = TPCH_DATA_PATH;
  page_size = C_PAGE_SIZE;

  switch (tableNumber) {
    case LINEITEM:
      //inputFileName = dataPath + "/lineitem_1percent.tbl.1";
      //inputFileName = dataPath + "/lineitem.tbl.1";
      inputFileName = "/data/rstore/tpch/scale10/lineitem.tbl.full";
      numOfColumns = 16;
      break;
    case ORDERS:
      //inputFileName = "/data/rstore/tpch/scale10/orders.tbl.full";
      inputFileName = "/data/rstore/tpch/scale40/orders.tbl.full";
      numOfColumns = 10;
      break;		
    default:
      cerr << "not sure what table you want to load, exiting..." << endl;
      exit(1);
  }

  fstream inFile;
  vector<string> tokens;
  vector<string>::iterator itr;
  inFile.open( inputFileName.c_str(), ios::in );

  if (!inFile.is_open()) {
    cout << inputFileName << " not found! " << endl;
  }
  for (unsigned i=0; i<numOfColumns; ++i) tokens.push_back("");
  cerr << "\tLoading " << inputFileName << "..." << endl;
  char str[512];
  int str_sz=sizeof(str);
  ssize_t byte_count=0;

  while ( !inFile.eof() ) {
    inFile.getline(str, str_sz);
    string s(str);
    if (s.length()) {
      if (tableNumber == LINEITEM)  {
        Tokenize(s, tokens, "|");
 
        // first read into a regular lineitem tuple

        lineitem.L_ORDERKEY = atoi(tokens[0].c_str());
        lineitem.L_PARTKEY = atoi(tokens[1].c_str());
        lineitem.L_SUPPKEY = atoi(tokens[2].c_str());
        lineitem.L_LINENUMBER = atoi(tokens[3].c_str());
        lineitem.L_QUANTITY = atoi(tokens[4].c_str());
        lineitem.L_EXTENDEDPRICE = atoi(tokens[5].c_str());
        lineitem.L_DISCOUNT = (int)(atof(tokens[6].c_str()) * 100.0 + 0.1);
        lineitem.L_TAX = (int)(atof(tokens[7].c_str()) * 100.0 + 0.1);
        lineitem.L_RETURNFLAG = *(tokens[8].c_str());
        lineitem.L_LINESTATUS = *(tokens[9].c_str());
        lineitem.L_SHIPDATE = dateToDays(tokens[10].c_str());
        lineitem.L_COMMITDATE = dateToDays(tokens[11].c_str());
        lineitem.L_RECEIPTDATE = dateToDays(tokens[12].c_str());
        memcpy(lineitem.L_SHIPINSTRUCT, tokens[13].c_str(), tokens[13].size()+1);
        memcpy(lineitem.L_SHIPMODE, (void*)tokens[14].c_str(), tokens[14].size()+1);
        //memcpy(lineitem.L_COMMENT, (void*)tokens[15].c_str(), tokens[15].size()+1);
        memcpy(lineitem.L_COMMENT, (void*)tokens[15].c_str(), 27);
        lineitem.L_COMMENT[26] = '\0';

        if (!compressed) {
          switch (columnNumber) {
            case L_ORDERKEY:
            case L_PARTKEY:
            case L_SUPPKEY:
            case L_LINENUMBER:
            case L_QUANTITY:
            case L_EXTENDEDPRICE:
              c_width = sizeof(int);
              *((int*)(&l_cstore_page.block[row_index * c_width])) =
                  atoi(tokens[columnNumber].c_str());
                  //cerr <<  tokens[columnNumber] << endl;
              break;
            case L_DISCOUNT:
            case L_TAX:
              c_width = sizeof(int);
              *((int*)(&l_cstore_page.block[row_index * c_width])) =
                  (int)(atof(tokens[columnNumber].c_str()) * 100.0 + 0.1);
              break;
            case L_RETURNFLAG: 
            case L_LINESTATUS:
              c_width = sizeof(char);
              l_cstore_page.block[row_index * c_width] = 
                  *(tokens[columnNumber].c_str());
              break;
            case L_SHIPDATE:
            case L_COMMITDATE:
            case L_RECEIPTDATE:
              c_width = sizeof(int);
              //cerr << "days=" << tokens[columnNumber].c_str() << endl;
              *((int*)(&l_cstore_page.block[row_index * c_width])) =
                  atoi(tokens[columnNumber].c_str());
              break;
            case L_SHIPINSTRUCT:
              c_width = 25;
              memcpy(&l_cstore_page.block[row_index * c_width],
                     tokens[columnNumber].c_str(), tokens[columnNumber].size()+1);
              break; 
            case L_SHIPMODE:
              c_width = 10;
              memcpy(&l_cstore_page.block[row_index * c_width],
                     tokens[columnNumber].c_str(), tokens[columnNumber].size()+1);
              break;
            case L_COMMENT:
              c_width = 69;
              memcpy(&l_cstore_page.block[row_index * c_width],
                     tokens[columnNumber].c_str(), 27);
              l_cstore_page.block[row_index * c_width + 26] = '\0';
              break;
            default:
              cerr << "not sure which column  you want to load, exiting..." << endl;
              exit(1);      
          } // switch
        }
        else { // compressed

          // L_PARTKEY, L_SUPPKEY, L_EXTENDEDPRICE remain the same   
 
          switch (columnNumber) {

            // L_ORDERKEY is stored as delta from previous value base value
            case L_ORDERKEY:
              if(row_index == 0) {
                base_L_ORDERKEY = lineitem.L_ORDERKEY;
                l_cstore_page.block[0] = 0;
              }
              else {
                c_width = sizeof(char);
                l_cstore_page.block[row_index * c_width] = (unsigned char)(
                  lineitem.L_ORDERKEY - base_L_ORDERKEY
                      - (int)l_cstore_page.block[(row_index-1)* c_width]);
              }
              break;

            // L_SHIPDATE, L_COMMITDATE, L_RECEIPTDATE are packed as short integers
            case L_SHIPDATE:
            case L_COMMITDATE:
            case L_RECEIPTDATE:
              c_width = sizeof(unsigned short);
              *((unsigned short*)(&l_cstore_page.block[row_index * c_width])) =
                  (unsigned short)(dateToDays(tokens[columnNumber].c_str()));
              break;
          
            // L_QUANTITY is packed into an 8-bit value
            case L_QUANTITY:
              c_width = sizeof(char);
              l_cstore_page.block[row_index * c_width] = 
                (unsigned char)lineitem.L_QUANTITY;
              break;

            // L_COMMENT is simply truncated to 28 bytes
            case L_COMMENT:
              c_width = 28;
              memcpy(&l_cstore_page.block[row_index * c_width],
                     lineitem.L_COMMENT, 27);
              break;
            
            // TODO: the rest of columns for LINEITEM

            default:
              cerr << "not sure which column  you want to load, exiting..." << endl;
              exit(1);
          } //switch  

        } // compressed

        row_index++;

        // check if page is full
        // (check if it doesn't fit another c_width value)

        if ((row_index+1) * c_width <= page_size) {
          ++counter;
          if ((counter % 100000) == 0)
            cerr << "count:" << counter << endl;
          continue;
        }
         
        // ..else we filled up a page 

        l_cstore_page.num_values = row_index;

        // we do the following anyways
        *(int*)(l_cstore_page.base) = base_L_ORDERKEY;

        byte_count = write(cstore_fd, &l_cstore_page, sizeof(cstore_page));
        assert(byte_count == sizeof(cstore_page));

        page_index++;
        row_index = 0;
        ++counter;
        if ( (counter%100000) == 0 ) {
          cerr << "counter:" << counter << endl;
        }

      }	
      else if (tableNumber == ORDERS)  {
        Tokenize(s, tokens, "|");
        orders.O_ORDERKEY = atoi(tokens[0].c_str());
        orders.O_CUSTKEY = atoi(tokens[1].c_str());
        orders.O_TOTALPRICE = (int)(atof(tokens[3].c_str()) * 100.0 + 0.1);
        orders.O_ORDERDATE = dateToDays(tokens[4].c_str());
        orders.O_SHIPPRIORITY = atoi(tokens[7].c_str());
        orders.O_ORDERSTATUS = *(tokens[2].c_str());
        memcpy(orders.O_ORDERPRIORITY, (void*)tokens[5].c_str(), 11);
        orders.O_ORDERPRIORITY[11] = '\0';

        int ti = 0; //token index
        switch (columnNumber) {
          case O_ORDERKEY:      { ti = 0; break; }
          case O_ORDERDATE:     { ti = 4; break; }
          case O_CUSTKEY:       { ti = 1; break; }
          case O_SHIPPRIORITY:  { ti = 7; break; }
          case O_TOTALPRICE:    { ti = 3; break; }
          case O_ORDERSTATUS:   { ti = 2; break; }
          case O_ORDERPRIORITY: { ti = 5; break; }
          default:
            cerr << "not sure which column  you want to load, exiting..." << endl;
            exit(1);
            break;
        } // token index

        if (!compressed) {
          switch (columnNumber) {
            case O_ORDERKEY:
            case O_CUSTKEY:
            case O_SHIPPRIORITY:
              c_width = sizeof(int);
              *((int*)(&o_cstore_page.block[row_index * c_width])) =
                  atoi(tokens[ti].c_str());
              break;
            case O_ORDERDATE:
              c_width = sizeof(int);
              *((int*)(&o_cstore_page.block[row_index * c_width])) =
                  dateToDays(tokens[ti].c_str());
              break;
            case O_TOTALPRICE:
              c_width = sizeof(int);
              *((int*)(&o_cstore_page.block[row_index * c_width])) =
                  (int)(atof(tokens[ti].c_str()) * 100.0 + 0.1);
              break;
            case O_ORDERSTATUS:
              c_width = sizeof(char);
              o_cstore_page.block[row_index * c_width] = 
                  *(tokens[ti].c_str());
              break;
            case O_ORDERPRIORITY:
              c_width = 11;
              //memcpy(&o_cstore_page.block[row_index * c_width], tokens[ti].c_str(), 11);
              memcpy(&o_cstore_page.block[row_index * c_width], orders.O_ORDERPRIORITY, 11);
              break;
            default:
              cerr << "not sure which column  you want to load, exiting..." << endl;
              exit(1);
              break;
          } // columnNumber
          row_index++;
          // check if page is full
          // (check if it doesn't fit another c_width value)
          if ((row_index+1) * c_width <= page_size) {
            ++counter;
            if ((counter % 100000) == 0)
              cerr << "count:" << counter << endl;
            continue;
          }
          // ..else we filled up a page 
          o_cstore_page.num_values = row_index;
          // we do the following anyways
          *(int*)(o_cstore_page.base) = base_O_ORDERKEY;
          byte_count = write(cstore_fd, &o_cstore_page, sizeof(cstore_page));
          assert(byte_count == sizeof(cstore_page));
          page_index++;
          row_index = 0;
          ++counter;
          if ( (counter%100000) == 0 ) {
            cerr << "counter:" << counter << endl;
          }
        } else { // Compressed

          // O_CUSTKEY, O_TOTALPRICE remain the same

          switch (columnNumber) {
  
            // CZ1 O_ORDERKEY is delta-encoded and stored as unsigned char
            case O_ORDERKEY:
#if 0
              if(row_index == 0) {
                base_O_ORDERKEY = orders.O_ORDERKEY;
                delta_prev_value = orders.O_ORDERKEY;
                *((unsigned char*)o_cstore_page.block) = (unsigned char)0;
              }
              else {
                c_width = sizeof(unsigned char);
                *((unsigned char*)(o_cstore_page.block + row_index*c_width)) = 
                    (unsigned char)(orders.O_ORDERKEY - delta_prev_value);
                delta_prev_value = orders.O_ORDERKEY;
              }
              break;
#endif
#if 1
              if(row_index == 0) {
                base_O_ORDERKEY = orders.O_ORDERKEY;
                delta_prev_value = orders.O_ORDERKEY;
                *((unsigned short*)o_cstore_page.block) = (unsigned short)0;
              }
              else {
                c_width = sizeof(unsigned short);
                *((unsigned short*)(o_cstore_page.block + row_index*c_width)) =
                    (unsigned short)(orders.O_ORDERKEY - base_O_ORDERKEY);
              }
              break;
#endif
 
            // CZ4 O_ORDERDATE is stored as short int 
            case O_ORDERDATE: 
             c_width = sizeof(unsigned short);
             *((unsigned short*)(&o_cstore_page.block[row_index * c_width])) =
               (unsigned short)(dateToDays(tokens[ti].c_str()));
              break;

            // CZ5 O_SHIPPRIORITY is bit-packed to 1 bit,
            // therefore 32 entries per uint_container
            case O_SHIPPRIORITY:
              c_width = sizeof(unsigned int);
              c_value_multiplier = 32;
              uTmp = (unsigned int)orders.O_SHIPPRIORITY;
              uint_container = uint_container | (uTmp << (container_index * 1));
              *((unsigned int*)(&o_cstore_page.block[row_index * c_width])) = uint_container;
              ++container_index;
              if (container_index == 32) {
                container_index = 0;
                uint_container = 0;
              }
              else {
                continue;
              }
              break;

            // CZ6 O_ORDERSTATUS is dict-encoded to 2 bits,
            // therefore 16 entries per uint_container
            case O_ORDERSTATUS:
              c_width = sizeof(unsigned int);
              c_value_multiplier = 16;
              found = false; 
              for (int i = 0; i < 3; i++) {
                if (*Status[i] == *(tokens[ti].c_str())) {
                  uTmp = (unsigned int) i;
                  found = true;
                  break;
                }
              }
              if (found == false) {
                cerr << "Error in data! exiting " << endl;
                exit(1);
              }
              uint_container = uint_container | (uTmp << (container_index * 2));
              *((unsigned int*)(&o_cstore_page.block[row_index * c_width])) = uint_container;
              ++container_index;
              if (container_index == 16) {
                container_index = 0;
                uint_container = 0;
              } 
              else {
                continue;
              } 
              break;

            // CZ7 O_ORDERPRIORITY  is dict-encoded to 3 bits,
            // therefore 10 entries per uint_container
            case O_ORDERPRIORITY:
              c_width = sizeof(unsigned int);
              c_value_multiplier = 10;            
              found = false; 
              for (int i = 0; i < 5; i++) {
                // comparing first 3 bytes is enough
                if (!memcmp(Priorities[i], orders.O_ORDERPRIORITY, 3)) {
                  uTmp = (unsigned int) i;
                  found = true;
                  break;
                } 
              } 
              if (found == false) {
                cerr << "Error in data! exiting " << endl;
                exit(1);
              } 
              uint_container = uint_container | (uTmp << (container_index * 3));
              *((unsigned int*)(&o_cstore_page.block[row_index * c_width])) = uint_container;
              ++container_index;
              if (container_index == 10) {
                container_index = 0;
                uint_container = 0;
              }
              else {
                continue;
              }
              break;

            default:
              cerr << "not sure which column  you want to load, exiting..." << endl;
              exit(1);
              break;
          } // switch

          ++row_index;
          // check if page is full
          // (check if it doesn't fit another c_width value)
          if ((row_index+1) * c_width <= page_size) {
            ++counter;
            if ((counter % 100000) == 0)
              cerr << "count:" << counter << endl;
            continue;
          }

          // ..else we filled up a page
          o_cstore_page.num_values = row_index;
          if (compressed) {      
            // num_values overrides
            if (c_value_multiplier)
              o_cstore_page.num_values = row_index * c_value_multiplier;
          }
          // we do the following anyways
          *(int*)(o_cstore_page.base) = base_O_ORDERKEY;
          byte_count = write(cstore_fd, &o_cstore_page, sizeof(cstore_page));
          assert(byte_count == sizeof(cstore_page));
          page_index++;
          row_index = 0;
          ++counter;
          if ( (counter%100000) == 0 ) {
            cerr << "counter:" << counter << endl;
          }

        } //orders compressed;
      } // tableNumber
    } // s.length()
    else break;
  }

  // tails..
  if (row_index || container_index) {
    if (tableNumber == LINEITEM) {
      l_cstore_page.num_values = row_index;
      // we do the following anyways
      *(int*)(l_cstore_page.base) = base_L_ORDERKEY;
      byte_count = write(cstore_fd, &l_cstore_page, sizeof(cstore_page));
      assert(byte_count == sizeof(cstore_page));
    }
    else if (tableNumber == ORDERS) {
    //ORDERS
      o_cstore_page.num_values = row_index;
      if (compressed) {
        // num_values overrides  BUG ALERT: note the + container_index
        if (c_value_multiplier)
          o_cstore_page.num_values = row_index  * c_value_multiplier + container_index;
      }
      // we do the following anyways
      *(int*)(o_cstore_page.base) = base_O_ORDERKEY;
      byte_count = write(cstore_fd, &o_cstore_page, sizeof(cstore_page));
      assert(byte_count == sizeof(cstore_page));
    }
  }

  //+ terminating page
  if (tableNumber == LINEITEM) {
    memset(&l_cstore_page, 0, sizeof(cstore_page));
    l_cstore_page.num_values = 0;
    byte_count = write(cstore_fd, &l_cstore_page, sizeof(cstore_page));
    assert(byte_count == sizeof(cstore_page));
  } else if (tableNumber == ORDERS) {
    memset(&o_cstore_page, 0, sizeof(cstore_page));
    o_cstore_page.num_values = 0;
    byte_count = write(cstore_fd, &o_cstore_page, sizeof(cstore_page));
    assert(byte_count == sizeof(cstore_page));
  }
  //-

  cerr << "\tFinished loading" << inputFileName <<"..." << endl;
  cerr << "\t loaded: " << page_index <<" pages / " << counter << " rows"<< endl;

  inFile.close();
}
