
// SELECT L_ORDERKEY, L_PARTKEY, L_SUPPKEY, L_LINENUMBER
// FROM lineitem
// where L_PARTKEY ~.1%

int SIZE = 16;

class Q : public scan_obj_t {
public:
  Q(int sz = SIZE) : scan_obj_t(sz, sizeof(l_tuple)) {}
  virtual bool predicate(tuple_t* t) {
    l_tuple* tuple = (l_tuple*)t->data;   
    if (tuple->L_PARTKEY < 2001)
      return true;
    return false;
  }
  virtual void project(tuple_t* in_tuple, tuple_t* out_tuple) {
    l_tuple* t = (l_tuple*)in_tuple->data;
    //memcpy(out_tuple->data, &(t->L_SHIPDATE), 16);
    *((int*)out_tuple->data) = t->L_ORDERKEY;
    *((int*)(out_tuple->data+4)) = t->L_PARTKEY;
    *((int*)(out_tuple->data+8)) = t->L_SUPPKEY;
    *((int*)(out_tuple->data+12)) = t->L_LINENUMBER;
  }
};

class P4 : public print_obj_t {
public:
  virtual void print_tuple(tuple_t* t) {
  cout << *((int*)(t->data)) << "|"
       << *((int*)(t->data+4)) << "|"
       << *((int*)(t->data+8)) << "|"
       << *((int*)(t->data+12)) << endl;
  }
};

///////////////////////////////////////////////////////////
// Query

void query() {
  executor_t* q = new executor_t(
                          new fscanR("L",
                          new Q()),
                      new NP());
                      //new P4());
  q->eval();
  delete q;
  return;
}

