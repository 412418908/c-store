
// SELECT L_PARTKEY
// FROM lineitem
// where L_PARTKEY~ .1%


class Q : public scan_obj_t {
public:
  Q(int sz = SIZE) : scan_obj_t(sz, sizeof(l_tuple)) {}
  virtual bool predicate(tuple_t* t) {
    l_tuple* tuple = (l_tuple*)t->data;   
    if (tuple->L_PARTKEY < 2001)
      return true;
    return false;
  }
  virtual void project(tuple_t* in_tuple, tuple_t* out_tuple) {
    l_tuple* t = (l_tuple*)in_tuple->data;
    //memcpy(out_tuple->data, &(t->L_SHIPDATE), 4);
    *((int*)out_tuple->data) = t->L_PARTKEY;
  }
};


///////////////////////////////////////////////////////////
// Query

void query() {
  SIZE = 4;
  executor_t* q = new executor_t(
                          new fscanR("L",
                          new Q()),
                      new NP());
  q->eval();
  delete q;
  return;
}

