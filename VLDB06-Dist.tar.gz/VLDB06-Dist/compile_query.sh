#!/bin/bash
trap abort_script 2    # abort if ctrl-c
#
abort_script()
{
    echo "ctrl-c detected! aborting..."
    exit 1
}
#
if [[ -e $1 ]]
  then
    cp $1 ./workload/tpch/tpch_query.cpp
  else
    echo $1 "not found!"
    exit 1
fi
#
make
